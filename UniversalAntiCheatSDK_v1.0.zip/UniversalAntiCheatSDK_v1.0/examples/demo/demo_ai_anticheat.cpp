// ============================================================================
// UniversalAntiCheatSDK - AI 反作弊分析 demo（云端 LLM 判定 + 内置模拟玩家）
// ----------------------------------------------------------------------------
// 演示内容：
//   1. 初始化反作弊 Hub
//   2. 注册 CAIAntiCheatModule（AI 反作弊分析模块）
//      - 开启内置 demo：自动生成模拟玩家，并注入作弊者 Player_0007
//      - 行为特征聚合后上报到 Python LLM 分析服务（默认 127.0.0.1:9001）
//      - LLM 返回判定（作弊/疑似/正常 + 理由）；服务不可达则本地规则兜底
//   3. 回调：AI 判定作弊 -> 打印/语音警告（"系统绑定中"风格）
//
// 前置：先启动云端分析服务
//   python python\anti_cheat_llm_server.py
// 编译：见 CMakeLists.txt（demo_ai_anticheat 目标）
// ============================================================================
#include "Source/AntiCheat/Public/CAntiCheatHub.h"
#include "Source/AntiCheat/Public/CAIAntiCheatModule.h"
#include "Source/CoreImpl/LogSystem/Public/CLogManager.h"

#include <cstdio>
#include <memory>
#include <thread>
#include <chrono>

#ifdef _WIN32
#include <windows.h>
#include <sapi.h>
#include <wchar.h>
#endif

using namespace MFS::CoreLock;

// 可选：Windows SAPI 语音播报（无语音引擎则静默，不影响逻辑）
static void SpeakText(const wchar_t* text)
{
#ifdef _WIN32
    if (!text || !*text) return;
    HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    ISpVoice* pVoice = nullptr;
    if (SUCCEEDED(hr) &&
        SUCCEEDED(CoCreateInstance(CLSID_SpVoice, nullptr, CLSCTX_ALL,
                                   IID_ISpVoice, reinterpret_cast<void**>(&pVoice))))
    {
        // 同步播放：避免 SAPI 异步 + 立即 CoUninitialize 导致的语音线程崩溃闪退
        pVoice->Speak(text, SPF_IS_XML, nullptr);
    }
    if (pVoice) pVoice->Release();
    CoUninitialize();
#else
    (void)text;
#endif
}

static std::wstring ToWide(const std::string& s)
{
#ifdef _WIN32
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    std::wstring w(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
#else
    return L"";
#endif
}

int main()
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
    printf("START: AI 反作弊分析 demo\n"); fflush(stdout);

    CLogManager::GetInstance().Initialize();
    CAntiCheatHub& hub = CAntiCheatHub::GetInstance();
    if (!hub.Initialize())
    {
        printf("[demo] 反作弊 Hub 初始化失败\n");
        return 1;
    }
    // 调小检查间隔，让 AI 判定能快速触发回调（真实接入可按需调整）
    SAntiCheatConfig cfg = hub.GetConfig();
    cfg.checkIntervalMs = 500;
    hub.SetConfig(cfg);
    hub.StartProtection();

    // ---------- 注册 AI 反作弊分析模块 ----------
    auto ai = std::make_unique<CAIAntiCheatModule>();
    ai->SetLLMEndpoint("http://127.0.0.1:9001/analyze");  // 云端 LLM 分析服务
    ai->SetEnableDemo(true);                              // 内置模拟玩家（含作弊者）
    hub.RegisterModule("AIAnalysis", std::move(ai));

    printf("[demo] AI 反作弊分析已接入（内置模拟玩家，作弊者 Player_0007）\n\n"); fflush(stdout);

    // ---------- 回调：AI 判定作弊 -> 警告 ----------
    hub.RegisterCallback([](const SAntiCheatResult& r)
    {
        if (r.passed) return;
        printf("========== AI 判定 ==========\n"); fflush(stdout);
        printf("  检测项 : %s\n", r.checkName.c_str());
        printf("  结论   : %s\n", r.reason.c_str());
        std::string warn = "当前有人开科技，系统绑定中。";
        printf("[AI 警告] %s\n", warn.c_str()); fflush(stdout);
        SpeakText(ToWide(warn).c_str());
        printf("=============================\n\n"); fflush(stdout);
    });

    // ---------- 运行足够帧，让 AI 模块采样、上报、判定 ----------
    printf("[demo] 运行中：AI 模块每 0.4s 采样一次，聚合后上报 LLM 分析服务...\n\n");
    for (int i = 0; i < 80; ++i)
    {
        hub.Update(0.1f);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    hub.StopProtection();
    hub.Shutdown();
    printf("[demo] 运行结束。\n");
    printf("\n演示结束，按任意键退出...\n"); fflush(stdout);
    getchar();
    return 0;
}
