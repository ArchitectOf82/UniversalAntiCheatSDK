@echo off
rem ============================================
rem  UniversalAntiCheatSDK - one-click build for demo exes
rem  Usage: double-click this file (or run from cmd)
rem  Requires: Visual Studio 2022+ with C++ toolchain
rem ============================================
chcp 65001 >nul
set REL=%~dp0..\..
set VC=C:\Program Files\Microsoft Visual Studio\18\Insiders\VC\Auxiliary\Build\vcvars64.bat
if not exist "%VC%" set VC=C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat
call "%VC%" >nul 2>&1

set INCS=/I"%REL%" /I"%REL%\include" /I"%REL%\Source\AntiCheat" /I"%REL%\Source\AntiCheat\Public" /I"%REL%\Source\AntiCheat\Private" /I"%REL%\Source\CoreImpl\AntiCheat\Public" /I"%REL%\Source\CoreImpl\LogSystem\Public" /I"%REL%\Source\Util\Public" /I"%REL%\Source\CoreImpl\BaseTemplate\Private"
set LIBS=%REL%\lib\AntiCheat.lib sapi.lib ole32.lib oleaut32.lib advapi32.lib iphlpapi.lib psapi.lib shell32.lib user32.lib ws2_32.lib

cd /d "%~dp0"

rem --- clear read-only stale exes (SDK FileProtect sets them read-only) ---
attrib -R demo_voice_warning.exe 2>nul
attrib -R demo_ai_anticheat.exe 2>nul
attrib -R demo_license.exe 2>nul
attrib -R demo_panel.exe 2>nul
del /f /q demo_voice_warning.exe 2>nul
del /f /q demo_ai_anticheat.exe 2>nul
del /f /q demo_license.exe 2>nul
del /f /q demo_panel.exe 2>nul

echo === [1/3] demo_voice_warning ===
cl /nologo /std:c++17 /EHsc /utf-8 %INCS% demo_voice_warning.cpp /link %LIBS% /out:demo_voice_warning.exe
if errorlevel 1 ( echo BUILD FAILED & exit /b 1 )

echo === [2/3] demo_ai_anticheat ===
cl /nologo /std:c++17 /EHsc /utf-8 %INCS% demo_ai_anticheat.cpp /link %LIBS% /out:demo_ai_anticheat.exe
if errorlevel 1 ( echo BUILD FAILED & exit /b 1 )

echo === [3/3] demo_license (online activation / trial) ===
cl /nologo /std:c++17 /EHsc /utf-8 %INCS% demo_license.cpp /link %LIBS% /out:demo_license.exe
if errorlevel 1 ( echo BUILD FAILED & exit /b 1 )

echo === [4/4] demo_panel (GUI demo launcher) ===
cl /nologo /std:c++17 /EHsc /utf-8 demo_panel.cpp /link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib /out:demo_panel.exe
if errorlevel 1 ( echo BUILD FAILED & exit /b 1 )

echo.
echo BUILD OK. generated:
echo   demo_voice_warning.exe
echo   demo_ai_anticheat.exe
echo   demo_license.exe
echo   demo_panel.exe  (GUI demo launcher)
echo.
echo Demo panel: double-click demo_panel.exe
echo Before running demo_license, start activation server:
echo   python python\activation_server.py
if /i not "%1"=="nopause" pause
