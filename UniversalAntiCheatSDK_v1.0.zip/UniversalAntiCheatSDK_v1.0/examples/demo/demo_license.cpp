// demo_license.cpp —— 在线激活 + 试用裁剪 演示
// 前置：先启动激活服务  python python\activation_server.py
// 运行前需服务器可用（否则走 ServerUnavailable / 离线兜底）
#include "Source/AntiCheat/Public/CAntiCheatHub.h"
#include "Source/CoreImpl/AntiCheat/Public/COnlineActivation.h"
#include "Source/CoreImpl/AntiCheat/Public/CSDKLicenseManager.h"
#include "Source/CoreImpl/LogSystem/Public/CLogManager.h"
#include <cstdio>
#include <string>
#include <vector>
#include <algorithm>
#ifdef _WIN32
#include <windows.h>
#endif
using namespace MFS::CoreLock;

static const char* StatusName(EActivationStatus s)
{
    switch (s)
    {
    case EActivationStatus::Activated: return "Activated";
    case EActivationStatus::NotActivated: return "NotActivated";
    case EActivationStatus::ActivationFailed: return "ActivationFailed";
    case EActivationStatus::ServerUnavailable: return "ServerUnavailable";
    case EActivationStatus::InvalidKey: return "InvalidKey";
    case EActivationStatus::HardwareMismatch: return "HardwareMismatch";
    case EActivationStatus::Expired: return "Expired";
    case EActivationStatus::Banned: return "Banned";
    case EActivationStatus::Revoked: return "Revoked";
    default: return "Unknown";
    }
}

static void PrintResp(const char* tag, const SActivationResponse& r)
{
    printf("[%s] status=%s | licenseType=%s | expire=%llu\n", tag,
           StatusName(r.status), r.licenseType.c_str(), (unsigned long long)r.expireDate);
    printf("       message: %s\n", r.message.c_str());
    printf("       allowedModules: ");
    for (const auto& m : r.allowedModules) printf("%s ", m.c_str());
    printf("\n");
}

static bool HasModule(const std::vector<std::string>& mods, const std::string& name)
{
    if (mods.empty()) return true; // 空=全开
    return std::find(mods.begin(), mods.end(), name) != mods.end();
}

int main()
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
    CLogManager::GetInstance().Initialize();
    COnlineActivation& oa = COnlineActivation::GetInstance();
    oa.Initialize();
    CSDKLicenseManager& lm = CSDKLicenseManager::GetInstance();
    lm.Initialize();

    const std::string hwid = "HW-DEMO-001";
    printf("========================================\n");
    printf(" UniversalAntiCheatSDK 在线激活 / 试用演示\n");
    printf(" 硬件 ID: %s\n", hwid.c_str());
    printf("========================================\n");

    // 1) 试用激活（30 天，模块裁剪：仅 Core/FileProtect）
    printf("\n--- [1] 试用激活 StartTrial ---\n");
    auto trial = oa.StartTrial(hwid);
    PrintResp("trial", trial);
    printf(">>> 试用版 AI 反作弊模块可用? %s\n",
           HasModule(trial.allowedModules, "AIAnalysis") ? "是(全开)" : "否(已被裁剪锁定)");

    // 2) 个人版激活
    printf("\n--- [2] 个人版激活 Activate(PE-DEMO-0001) ---\n");
    auto pe = oa.Activate("PE-DEMO-0001", hwid);
    PrintResp("personal", pe);

    // 3) 商业版激活
    printf("\n--- [3] 商业版激活 Activate(CO-DEMO-0001) ---\n");
    auto co = oa.Activate("CO-DEMO-0001", hwid);
    PrintResp("commercial", co);
    printf(">>> 商业版 AI 反作弊模块可用? %s\n",
           HasModule(co.allowedModules, "AIAnalysis") ? "是" : "否");

    // 4) 在线校验
    printf("\n--- [4] 在线校验 Validate ---\n");
    auto v = oa.Validate("CO-DEMO-0001", hwid);
    printf("[validate] isValid=%s remainingDays=%llu online=%s\n",
           v.isValid ? "是" : "否", (unsigned long long)v.remainingDays, v.isOnline ? "是" : "否");
    printf("           message: %s\n", v.errorMessage.c_str());

    oa.Shutdown();
    lm.Shutdown();
    printf("\n演示结束，按任意键退出...\n"); fflush(stdout);
    getchar();
    return 0;
}
