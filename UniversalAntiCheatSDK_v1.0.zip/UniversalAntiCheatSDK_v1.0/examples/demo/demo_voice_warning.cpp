// ============================================================================
// UniversalAntiCheatSDK - 语音公示 demo（隔离靶机 + 全局点名 / 私聊通道）
// ----------------------------------------------------------------------------
// 演示内容：
//   1. 初始化反作弊 Hub（CLogManager + CAntiCheatHub）
//   2. 注册一个"模拟作弊检测器"，在若干帧后判定某玩家开科技
//   3. 语音公示模块：检测到作弊 →
//        a) 全局广播：向所有玩家播报「当前有人开科技」并点名作弊者 ID
//        b) 私聊通道：单独一条语音只发给作弊者本人（威慑式警告）
//   语音用 Windows SAPI TTS（系统未装中文语音则退回控制台文本，不影响逻辑）
//
// 编译：见 build_demo.bat（cl + AntiCheat.lib）
// ============================================================================
#include "Source/AntiCheat/Public/CAntiCheatHub.h"
#include "Source/CoreImpl/AntiCheat/Public/IAntiCheatModule.h"
#include "Source/CoreImpl/LogSystem/Public/CLogManager.h"

#include <cstdio>
#include <cstring>
#include <memory>
#include <string>
#include <thread>
#include <chrono>

#include <windows.h>
#include <sapi.h>
#include <wchar.h>

using namespace MFS::CoreLock;

// ---------------------------------------------------------------------------
// 模拟作弊检测器：若干帧后判定目标玩家"开科技"（用于演示公示触发）
// ---------------------------------------------------------------------------
class CFakeCheatDetector : public IAntiCheatModule
{
public:
    CFakeCheatDetector(std::string targetId, int framesToCatch)
        : m_target(std::move(targetId)), m_counter(0), m_frames(framesToCatch) {}

    const char* GetName() const override { return "FakeCheatDetector"; }

    bool Check(SAntiCheatResult& out) override
    {
        if (++m_counter >= m_frames)
        {
            out.passed   = false;
            out.checkName = "SpeedHack/TimingAnalysis";
            out.reason   = m_target;          // 作弊者标识（可换成玩家 ID）
            out.severity = 0.95f;             // critical
            return false;
        }
        out.passed   = true;
        out.checkName = "FakeCheatDetector";
        out.severity = 0.0f;
        return true;
    }

private:
    std::string m_target;
    int m_counter;
    int m_frames;
};

// ---------------------------------------------------------------------------
// 语音播报：Windows SAPI TTS（异步，不阻塞；无语音引擎则静默退回文本）
// ---------------------------------------------------------------------------
static void SpeakText(const wchar_t* text)
{
    if (!text || !*text) return;
    HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    ISpVoice* pVoice = nullptr;
    if (SUCCEEDED(hr) &&
        SUCCEEDED(CoCreateInstance(CLSID_SpVoice, nullptr, CLSCTX_ALL,
                                   IID_ISpVoice, reinterpret_cast<void**>(&pVoice))))
    {
        // 同步播放：避免 SAPI 异步 + 立即 CoUninitialize 导致的语音线程崩溃闪退
        pVoice->Speak(text, SPF_IS_XML, nullptr);
    }
    if (pVoice) pVoice->Release();
    CoUninitialize();
}

// 宽字符串工具（便于 SAPI 朗读中文）
static std::wstring ToWide(const std::string& s)
{
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    std::wstring w(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}

int main()
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
    printf("START: enter main\n"); fflush(stdout);
    // ---------- 1. 初始化反作弊 ----------
    CLogManager::GetInstance().Initialize();
    CAntiCheatHub& hub = CAntiCheatHub::GetInstance();
    if (!hub.Initialize())
    {
        printf("[demo] 反作弊 Hub 初始化失败\n");
        return 1;
    }
    hub.StartProtection();
    printf("[demo] 反作弊已启动，监控隔离靶机...\n\n"); fflush(stdout);

    // ---------- 2. 注册模拟作弊检测器（隔离靶机：不扫描任何外部游戏进程） ----------
    const std::string cheaterId = "Player_0786";   // 作弊者 ID
    hub.RegisterModule("FakeCheat", std::make_unique<CFakeCheatDetector>(cheaterId, 5));

    // ---------- 3. 语音公示：检测到作弊 → 全局点名 + 私聊 ----------
    hub.RegisterCallback([&](const SAntiCheatResult& r)
    {
        if (r.passed) return;

        printf("========== 检测到作弊 ==========\n"); fflush(stdout);
        printf("  作弊者 ID : %s\n", r.reason.c_str());
        printf("  检测项    : %s\n", r.checkName.c_str());
        printf("  威胁等级  : %.2f (critical)\n", r.severity);

        // (a) 全局广播：向所有玩家点名
        std::string global = "当前有人开科技！作弊者ID " + r.reason + "，已定位。";
        printf("[全局广播] %s\n", global.c_str()); fflush(stdout);
        SpeakText(ToWide(global).c_str());

        // (b) 私聊通道：单独发给作弊者本人（威慑式警告）
        std::string privateMsg = "系统绑定中，绑定失败，开科技了菜鸡。";
        printf("[私聊通道 -> %s] %s\n", r.reason.c_str(), privateMsg.c_str()); fflush(stdout);
        SpeakText(ToWide(privateMsg).c_str());

        printf("===============================\n\n"); fflush(stdout);
    });

    // ---------- 4. 运行若干帧，让检测器触发 ----------
    for (int i = 0; i < 12; ++i)
    {
        hub.Update(0.1f);
        std::this_thread::sleep_for(std::chrono::milliseconds(150));
    }

    // ---------- 5. 关闭 ----------
    hub.StopProtection();
    hub.Shutdown();
    printf("[demo] 运行结束。\n"); fflush(stdout);
    printf("\n演示结束，按任意键退出...\n"); fflush(stdout);
    getchar();
    return 0;
}
