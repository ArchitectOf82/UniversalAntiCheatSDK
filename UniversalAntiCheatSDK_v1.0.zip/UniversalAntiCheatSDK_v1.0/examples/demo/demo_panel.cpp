// ============================================================================
// UniversalAntiCheatSDK - 演示面板（GUI）
// ----------------------------------------------------------------------------
// 点开一个窗口：查看 SDK 能力说明 + 一键启动各 demo
//   [语音点名演示]  demo_voice_warning.exe   语音公示：全局点名 + 私聊威慑
//   [AI 反作弊演示] demo_ai_anticheat.exe    AI 判定作弊（先起 LLM 服务更佳，不起了走本地兜底）
//   [激活/试用演示] demo_license.exe         试用30天裁剪 → 个人/商业版激活（先起激活服务）
// 编译：见 build_demo.bat（纯 Win32 GUI，不依赖 AntiCheat.lib）
// ============================================================================
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <string>
#include <vector>
#include <cstdio>
#include <cstdarg>

// ---- 控件 ID ----
enum { IDC_BTN_VOICE = 1001, IDC_BTN_AI, IDC_BTN_LICENSE, IDC_BTN_EXIT, IDC_EDIT_LOG };

static HWND g_hLog = nullptr;

// ---------------------------------------------------------------------------
// 日志输出到面板编辑框
// ---------------------------------------------------------------------------
static void Log(const char* fmt, ...)
{
    char buf[2048];
    va_list ap; va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    if (g_hLog)
    {
        // UTF-8 窄字符 -> 宽字符，再写给 Unicode Edit 控件，避免乱码
        int n = MultiByteToWideChar(CP_UTF8, 0, buf, -1, nullptr, 0);
        std::wstring wbuf(n, L'\0');
        MultiByteToWideChar(CP_UTF8, 0, buf, -1, &wbuf[0], n);

        int cur = (int)GetWindowTextLengthW(g_hLog);
        SendMessageW(g_hLog, EM_SETSEL, cur, cur);
        SendMessageW(g_hLog, EM_REPLACESEL, FALSE, (LPARAM)wbuf.c_str());
        SendMessageW(g_hLog, EM_SCROLLCARET, 0, 0);
    }
}

// ---------------------------------------------------------------------------
// 启动同目录下的某个 demo exe（弹出控制台窗口运行）
// ---------------------------------------------------------------------------
static void RunDemo(const char* exeName)
{
    char cur[MAX_PATH];
    GetModuleFileNameA(NULL, cur, MAX_PATH);
    std::string dir(cur);
    auto p = dir.find_last_of('\\');
    if (p != std::string::npos) dir = dir.substr(0, p);
    std::string path = dir + "\\" + exeName;

    STARTUPINFOA si{}; si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (CreateProcessA(NULL, (LPSTR)path.c_str(), NULL, NULL, FALSE,
                       0, NULL, dir.c_str(), &si, &pi))
    {
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        Log("[已启动] %s (独立窗口运行)\n", exeName);
    }
    else
    {
        Log("[失败] 无法启动 %s，错误码 %lu（请确认该 exe 与面板同目录）\n", exeName, GetLastError());
    }
}

// ---------------------------------------------------------------------------
// 回调
// ---------------------------------------------------------------------------
static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_COMMAND:
        switch (LOWORD(wParam))
        {
        case IDC_BTN_VOICE:   Log("\n===== 启动：语音点名演示 =====\n"); RunDemo("demo_voice_warning.exe"); break;
        case IDC_BTN_AI:      Log("\n===== 启动：AI 反作弊演示 =====\n"); RunDemo("demo_ai_anticheat.exe"); break;
        case IDC_BTN_LICENSE: Log("\n===== 启动：激活/试用演示 =====\n"); RunDemo("demo_license.exe"); break;
        case IDC_BTN_EXIT:    DestroyWindow(hwnd); break;
        }
        return 0;

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

// ---------------------------------------------------------------------------
// 入口
// ---------------------------------------------------------------------------
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow)
{
    // 控制台切 UTF-8（若从命令行启动）
    SetConsoleOutputCP(CP_UTF8);

    WNDCLASSW wc{};
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.hCursor       = LoadCursorW(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = L"UACDemoPanel";
    RegisterClassW(&wc);

    HWND hwnd = CreateWindowW(wc.lpszClassName, L"UniversalAntiCheatSDK 演示面板",
                              WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
                              660, 620, NULL, NULL, hInst, NULL);
    if (!hwnd) return 1;

    // 字体（中文）
    HFONT hTitle = CreateFontW(-20, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET,
                               0, 0, 0, 0, L"Microsoft YaHei");
    HFONT hBody  = CreateFontW(-15, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
                               0, 0, 0, 0, L"Microsoft YaHei");
    HFONT hBtn   = CreateFontW(-16, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
                               0, 0, 0, 0, L"Microsoft YaHei");

    HWND hTitleW = CreateWindowW(L"STATIC", L"UniversalAntiCheatSDK · 游戏通用反作弊演示",
                                 WS_CHILD | WS_VISIBLE, 20, 12, 600, 30, hwnd, NULL, hInst, NULL);
    SendMessageW(hTitleW, WM_SETFONT, (WPARAM)hTitle, TRUE);

    HWND hSubW = CreateWindowW(L"STATIC",
        L"单机、网游通吃：联机靠「检测」（AI 判开挂），单机靠「防护」（防破解/防盗版）。"
        L"\r\n点击下方按钮启动对应演示（demo 独立窗口运行，面板可继续操作）。",
        WS_CHILD | WS_VISIBLE, 20, 46, 610, 40, hwnd, NULL, hInst, NULL);
    SendMessageW(hSubW, WM_SETFONT, (WPARAM)hBody, TRUE);

    // 模块说明
    HWND hModW = CreateWindowW(L"STATIC",
        L"内置能力："
        L"\r\n  反调试 / 内存校验 / 代码完整性 / 硬件指纹 / 时间锁 / 自毁 / 动态迷宫混淆"
        L"\r\n  文件保护 / 行为自学习 / AI 反作弊分析（云端 LLM 判定 + 本地兜底）"
        L"\r\n  语音公示（全局点名 + 私聊威慑，文案完全可自定义）"
        L"\r\n  在线激活 + 试用裁剪（试用 30 天，AI 锁定；激活码按档位解锁）",
        WS_CHILD | WS_VISIBLE | SS_LEFT, 20, 92, 610, 110, hwnd, NULL, hInst, NULL);
    SendMessageW(hModW, WM_SETFONT, (WPARAM)hBody, TRUE);

    // 日志区
    g_hLog = CreateWindowW(L"EDIT", L"",
        WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL,
        20, 210, 610, 300, hwnd, (HMENU)IDC_EDIT_LOG, hInst, NULL);
    SendMessageW(g_hLog, WM_SETFONT, (WPARAM)hBody, TRUE);

    // 按钮行
    CreateWindowW(L"BUTTON", L"① 语音点名演示", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                  20, 525, 140, 36, hwnd, (HMENU)IDC_BTN_VOICE, hInst, NULL);
    CreateWindowW(L"BUTTON", L"② AI 反作弊演示", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                  170, 525, 140, 36, hwnd, (HMENU)IDC_BTN_AI, hInst, NULL);
    CreateWindowW(L"BUTTON", L"③ 激活/试用演示", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                  320, 525, 140, 36, hwnd, (HMENU)IDC_BTN_LICENSE, hInst, NULL);
    CreateWindowW(L"BUTTON", L"退出", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                  470, 525, 160, 36, hwnd, (HMENU)IDC_BTN_EXIT, hInst, NULL);

    // 应用到按钮
    for (HWND hc = GetWindow(hwnd, GW_CHILD); hc; hc = GetWindow(hc, GW_HWNDNEXT))
    {
        wchar_t cls[32];
        GetClassNameW(hc, cls, 32);
        if (wcscmp(cls, L"Button") == 0) SendMessageW(hc, WM_SETFONT, (WPARAM)hBtn, TRUE);
    }

    Log("UniversalAntiCheatSDK 演示面板已就绪。\n");
    Log("提示：AI 演示前可先运行  python python\\anti_cheat_llm_server.py\n");
    Log("      激活演示前可先运行  python python\\activation_server.py\n");

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return (int)msg.wParam;
}
