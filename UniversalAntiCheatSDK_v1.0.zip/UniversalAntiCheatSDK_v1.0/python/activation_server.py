# -*- coding: utf-8 -*-
"""
UniversalAntiCheatSDK —— 在线激活服务（授权服务器）
提供：激活码验证 / 硬件绑定 / 授权签发 / 试用发放 / 限激活次数 / 到期校验

用法：  python activation_server.py [--port 8080] [--db activation_db.json]
端点：
  POST /activate   {licenseKey, hardwareId}          -> 签发正式授权
  POST /validate   {licenseKey, hardwareId, token}   -> 校验授权
  POST /trial      {hardwareId}                      -> 发放 30 天试用（裁剪模块）
  GET  /health                                        -> 服务存活
返回 JSON：status / message / sessionToken / licenseType / expireDate / allowedModules
"""
import http.server
import json
import time
import os
import sys
import hashlib
import secrets

# ============================================================
# 配置
# ============================================================
HOST = "0.0.0.0"
PORT = 8080
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(SCRIPT_DIR, "activation_db.json")

TRIAL_DAYS = 30                # 试用天数（30 天）
TRIAL_MODULES = ["Core", "FileProtect"]   # 试用版仅开放基础检测（锁 AI / 高级防护）

# 授权档位定义
LICENSE_TYPES = {
    "TRIAL":       {"label": "Trial",       "days": TRIAL_DAYS,      "max": 1,  "modules": TRIAL_MODULES},
    "PERSONAL":    {"label": "Personal",    "days": 365,             "max": 1,  "modules": ["Core", "FileProtect", "Memory", "Learn"]},
    "COMMERCIAL":  {"label": "Commercial",  "days": 365 * 3,         "max": 3,  "modules": ["Core", "FileProtect", "Memory", "Learn",
                                                                                          "AdvancedAntiDebug", "CodeIntegrity", "TimeLock",
                                                                                          "HardwareFingerprint", "AIAnalysis", "OnlineActivation"]},
    "ENTERPRISE":  {"label": "Enterprise",  "days": 365 * 10,        "max": 10, "modules": ["*"]},
}

# 预置激活码库（演示 / 生产替换为你的正式发码库）
ACTIVATION_KEYS = {
    "TRIAL-DEMO-0001": "TRIAL",
    "PE-DEMO-0001":    "PERSONAL",
    "CO-DEMO-0001":    "COMMERCIAL",
    "EN-DEMO-0001":    "ENTERPRISE",
}

# ============================================================
# 持久化数据库
# ============================================================
def load_db():
    if os.path.exists(DB_PATH):
        try:
            with open(DB_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"keys": {}, "hw": {}}

def save_db(db):
    with open(DB_PATH, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

def make_token():
    return secrets.token_hex(16)

def hardware_fingerprint(hardware_id):
    """服务端硬件标识：对客户端上报的硬件 ID 做二次散列，服务端不存明文标识外的信息。"""
    return hashlib.sha256(hardware_id.encode("utf-8")).hexdigest()[:32]

# ============================================================
# 授权逻辑
# ============================================================
def resp(status, message, **extra):
    out = {"status": status, "message": message}
    out.update(extra)
    return out

def handle_activate(db, body):
    key = (body.get("licenseKey") or "").strip()
    hwid_raw = (body.get("hardwareId") or "").strip()
    if not key or not hwid_raw:
        return resp("invalid", "licenseKey/hardwareId missing")
    hwid = hardware_fingerprint(hwid_raw)

    ltype = ACTIVATION_KEYS.get(key)
    if not ltype:
        return resp("invalid", "invalid license key")

    cfg = LICENSE_TYPES[ltype]
    rec = db["keys"].setdefault(key, {"type": ltype, "activated": []})

    # 该激活码已绑定硬件
    if hwid not in rec["activated"]:
        if len(rec["activated"]) >= cfg["max"]:
            return resp("banned", "activation limit reached for this key")
        rec["activated"].append(hwid)

    # 授权到期时间
    expire = int(time.time()) + cfg["days"] * 86400
    token = make_token()
    db["hw"][hwid] = {
        "type": ltype,
        "token": token,
        "expire": expire,
        "modules": cfg["modules"],
        "activated": int(time.time()),
    }
    # 正式授权已发放，清除该硬件的试用记录（校验不再走 trial 分支）
    db.setdefault("trial", {}).pop(hwid, None)
    save_db(db)
    return resp("activated", "license activated",
                sessionToken=token,
                licenseType=cfg["label"],
                expireDate=expire,
                allowedModules=cfg["modules"])

def handle_validate(db, body):
    key = (body.get("licenseKey") or "").strip()
    hwid_raw = (body.get("hardwareId") or "").strip()
    token = (body.get("token") or "").strip()
    if not hwid_raw:
        return resp("invalid", "hardwareId missing")
    hwid = hardware_fingerprint(hwid_raw)

    # 试用授权校验（trial 记录独立于正式授权）
    trial = db.get("trial", {})
    if hwid in trial:
        now = int(time.time())
        if now >= trial[hwid]["expire"]:
            return resp("trial_expired", "trial expired", remainingDays=0, licenseType="Trial")
        remain = int((trial[hwid]["expire"] - now) / 86400)
        return resp("valid", "trial valid", remainingDays=remain, licenseType="Trial",
                    expireDate=trial[hwid]["expire"], allowedModules=trial[hwid]["modules"])

    rec = db["hw"].get(hwid)
    if not rec:
        return resp("not_activated", "no activation for this hardware")
    if key and ACTIVATION_KEYS.get(key) != rec["type"]:
        return resp("invalid", "license key mismatch")
    if token and rec.get("token") != token:
        return resp("invalid", "token mismatch")

    now = int(time.time())
    if now >= rec["expire"]:
        return resp("expired", "license expired",
                    remainingDays=0, licenseType=LICENSE_TYPES[rec["type"]]["label"])
    remain = int((rec["expire"] - now) / 86400)
    return resp("valid", "license valid",
                remainingDays=remain,
                licenseType=LICENSE_TYPES[rec["type"]]["label"],
                expireDate=rec["expire"],
                allowedModules=rec["modules"])

def handle_trial(db, body):
    hwid_raw = (body.get("hardwareId") or "").strip()
    if not hwid_raw:
        return resp("invalid", "hardwareId missing")
    hwid = hardware_fingerprint(hwid_raw)

    # 已激活正式授权则不再发放试用
    if hwid in db["hw"]:
        return resp("already_licensed", "hardware already activated")

    trial = db.setdefault("trial", {})
    if hwid in trial:
        # 复用试用到期时间（防止改时间无限试）
        expire = trial[hwid]["expire"]
        state = "trial_expired" if int(time.time()) >= expire else "trial"
    else:
        expire = int(time.time()) + TRIAL_DAYS * 86400
        trial[hwid] = {"expire": expire, "modules": TRIAL_MODULES}
        state = "trial"

    save_db(db)
    return resp(state, "trial granted",
                sessionToken="TRIAL_" + hwid,
                licenseType="Trial",
                expireDate=expire,
                allowedModules=TRIAL_MODULES)

# ============================================================
# HTTP 服务
# ============================================================
class Handler(http.server.BaseHTTPRequestHandler):
    def _read_body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def _send(self, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.split("?")[0] == "/health":
            self._send({"status": "ok", "service": "UniversalAntiCheatSDK-Activation", "time": int(time.time())})
        else:
            self._send(resp("not_found", "unknown endpoint"))

    def do_POST(self):
        db = load_db()
        body = self._read_body()
        path = self.path.split("?")[0]
        if path == "/activate":
            self._send(handle_activate(db, body))
        elif path == "/validate":
            self._send(handle_validate(db, body))
        elif path == "/trial":
            self._send(handle_trial(db, body))
        else:
            self._send(resp("not_found", "unknown endpoint"))

    def log_message(self, fmt, *args):
        sys.stderr.write("[%s] %s\n" % (time.strftime("%H:%M:%S"), fmt % args))

def main():
    global PORT, DB_PATH
    args = sys.argv[1:]
    i = 0
    while i < len(args):
        if args[i] == "--port" and i + 1 < len(args):
            PORT = int(args[i + 1]); i += 2
        elif args[i] == "--db" and i + 1 < len(args):
            DB_PATH = args[i + 1]; i += 2
        else:
            i += 1
    print("=" * 60)
    print("UniversalAntiCheatSDK 在线激活服务")
    print("  listen : http://%s:%d" % (HOST, PORT))
    print("  数据库 : %s" % DB_PATH)
    print("  演示激活码: TRIAL-DEMO-0001 / PE-DEMO-0001 / CO-DEMO-0001 / EN-DEMO-0001")
    print("  端点   : POST /activate  POST /validate  POST /trial  GET /health")
    print("=" * 60)
    server = http.server.ThreadingHTTPServer((HOST, PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止")

if __name__ == "__main__":
    main()
