﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"

#include <windows.h>
#include <string>
#include <vector>
#include <map>

namespace MFS::CoreLock {

struct ProtectedFileInfo
{
    std::string filePath;
    uint64_t originalHash;
    bool isLocked;
    bool isReadOnly;
    HANDLE hFile;
};

class CFileProtector
{
public:
    CFileProtector() noexcept;
    ~CFileProtector() noexcept;

    bool AddProtectedFile(const std::string& filePath, bool lockFile = true, bool setReadOnly = true);
    bool RemoveProtectedFile(const std::string& filePath);
    bool ProtectAllFiles();
    bool UnprotectAllFiles();

    bool CheckFileIntegrity(const std::string& filePath);
    bool CheckAllFilesIntegrity();

    bool LockFile(const std::string& filePath);
    bool UnlockFile(const std::string& filePath);

    bool SetFileReadOnly(const std::string& filePath, bool readOnly);

    uint64_t CalculateFileHash(const std::string& filePath);

    size_t GetProtectedFileCount() const noexcept;
    const std::map<std::string, ProtectedFileInfo>& GetProtectedFiles() const noexcept;

private:
    CORE_NO_COPY_MOVE(CFileProtector);

    bool LockFileByHandle(const std::string& filePath, HANDLE& outHandle);
    bool UnlockFileByHandle(HANDLE hFile);

    std::map<std::string, ProtectedFileInfo> m_protectedFiles;
};

} // namespace MFS::CoreLock