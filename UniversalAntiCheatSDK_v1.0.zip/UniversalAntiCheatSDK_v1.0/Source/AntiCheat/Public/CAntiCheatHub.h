﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CFileProtector.h"
#include "Source/CoreImpl/AntiCheat/Public/IAntiCheatModule.h"

#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <unordered_map>

namespace MFS::CoreLock {

enum class EAntiCheatStatus : uint32_t
{
    Idle = 0,
    Protecting,
    ThreatDetected,
    SelfDestructing,
    Protected
};

enum class EThreatLevel : uint32_t
{
    None = 0,
    Low,
    Medium,
    High,
    Critical
};

struct ProtectionReport
{
    EThreatLevel level;
    std::string threatType;
    std::string description;
    uint64_t timestamp;
};

class CAntiCheatHub : public CSingleton<CAntiCheatHub>, public IFeature
{
public:
    CAntiCheatHub() noexcept;
    virtual ~CAntiCheatHub() noexcept = default;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    bool StartProtection();
    bool StopProtection();
    bool IsProtecting() const noexcept;

    EAntiCheatStatus GetStatus() const noexcept;
    EThreatLevel GetCurrentThreatLevel() const noexcept;

    void FilterGameData(std::string& data);
    void TriggerSelfDestruct();

    bool AddFileProtection(const std::string& filePath);
    bool RemoveFileProtection(const std::string& filePath);
    bool ProtectAllCoreFiles();
    bool CheckFileIntegrity(const std::string& filePath);
    bool CheckAllFilesIntegrity();

    /**
     * 注册自定义反作弊模块
     * 游戏开发者通过此接口实现自定义反作弊逻辑
     * @param moduleName 模块名称（唯一标识）
     * @param module 模块实例指针（由Hub管理生命周期）
     * @return true=注册成功
     *
     * 使用示例：
     *   class CWallhackDetector : public IAntiCheatModule { ... };
     *   CAntiCheatHub::GetInstance().RegisterModule("WallhackDetector", std::make_unique<CWallhackDetector>());
     */
    bool RegisterModule(const std::string& moduleName, std::unique_ptr<IAntiCheatModule> module);

    /**
     * 注销自定义反作弊模块
     * @param moduleName 模块名称
     * @return true=注销成功
     */
    bool UnregisterModule(const std::string& moduleName);

    /**
     * 获取已注册模块列表
     */
    std::vector<std::string> GetRegisteredModuleNames() const;

    /**
     * 启用/禁用指定模块
     */
    void SetModuleEnabled(const std::string& moduleName, bool enabled);

    /**
     * 启用/禁用所有自定义模块
     */
    void SetAllModulesEnabled(bool enabled);

    /**
     * 立即执行一次所有模块检查
     * @param outResults 输出所有检查结果
     * @return true=所有模块通过, false=有模块检测到作弊
     */
    bool RunAllChecks(std::vector<SAntiCheatResult>& outResults);

    /**
     * 设置反作弊配置
     */
    void SetConfig(const SAntiCheatConfig& config) { m_config = config; }
    const SAntiCheatConfig& GetConfig() const { return m_config; }

    /**
     * 注册反作弊事件回调
     * 当检测到作弊时触发
     * @param callback 回调函数
     */
    void RegisterCallback(AntiCheatCallback callback);

    /**
     * 清除所有事件回调
     */
    void ClearCallbacks();

private:
    CORE_NO_COPY_MOVE(CAntiCheatHub);

    void ProtectDefaultCoreFiles();
    void CheckCustomModules(f32 deltaTime);
    void FireCallbacks(const SAntiCheatResult& result);

    EFeatureState m_state;
    EAntiCheatStatus m_status;
    EThreatLevel m_currentThreat;
    std::atomic<bool> m_isProtecting;
    std::atomic<bool> m_selfDestructTriggered;
    CFileProtector m_fileProtector;

    // 自定义模块注册表
    std::unordered_map<std::string, std::unique_ptr<IAntiCheatModule>> m_customModules;

    // 反作弊配置
    SAntiCheatConfig m_config;

    // 事件回调列表
    std::vector<AntiCheatCallback> m_callbacks;

    // 检查计时器
    f32 m_checkTimer;
};

} // namespace MFS::CoreLock