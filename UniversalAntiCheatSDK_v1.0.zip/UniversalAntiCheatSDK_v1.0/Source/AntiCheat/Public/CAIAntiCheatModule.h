#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "Source/CoreImpl/AntiCheat/Public/IAntiCheatModule.h"

#include <string>
#include <deque>
#include <map>

namespace MFS::CoreLock {

/**
 * 行为特征样本（AI 反作弊分析输入）
 * 游戏端通过 ReportBehavior() 喂入每个玩家的行为数据，
 * AI 分析层据此判断是"真人操作"还是"外挂/脚本/超人类反应"。
 */
struct SBehaviorSample
{
    std::string playerId;      // 玩家标识
    float speed = 0.f;         // 移动速度 m/s
    float acceleration = 0.f;  // 加速度 m/s^2
    float aimPrecision = 0.f;  // 瞄准精度 0~1（锁头外挂趋近 1.0）
    float reactionTimeMs = 0.f;// 反应时间 ms（外挂趋近极小值）
    float hitRate = 0.f;       // 命中率 0~1
    float opFrequency = 0.f;   // 操作频率 次/秒（宏/脚本异常偏高）
    float health = 100.f;      // 生命值
    float distance = 0.f;      // 累计位移（检测瞬移/飞行）
    uint64_t timestamp = 0;    // 采样时间戳(ms)
};

/**
 * 云端 LLM 判定结果
 */
struct SAIVerdict
{
    bool cheating = false;     // 判定作弊
    bool suspected = false;    // 疑似（待人工/更严复查）
    float confidence = 0.f;    // 置信度 0~1
    std::string verdict;       // "cheat" / "suspect" / "normal"
    std::string reason;        // 判定理由
    std::string engine;        // "llm" / "local"
};

/**
 * AI 反作弊分析模块
 *
 * 职责：接入云端 LLM 分析，把"检测结果 + 行为特征"上报给大模型，
 *       由 AI 判断复杂/隐蔽作弊并降低误报；服务端不可达时自动降级为本地规则。
 *
 * 接入方式（作为 IAntiCheatModule 注册进 Hub）：
 *   auto ai = std::make_unique<CAIAntiCheatModule>();
 *   ai->SetLLMEndpoint("http://127.0.0.1:9001/analyze");
 *   ai->SetEnableDemo(true);   // 开启内置模拟玩家（演示用）
 *   hub.RegisterModule("AIAnalysis", std::move(ai));
 *
 * 真实游戏接入：关掉 demo，循环调用 ReportBehavior(sample) 喂真实行为数据即可。
 */
class CAIAntiCheatModule : public IAntiCheatModule
{
public:
    CAIAntiCheatModule() noexcept = default;
    virtual ~CAIAntiCheatModule() noexcept = default;

    // ---- IAntiCheatModule ----
    const char* GetName() const override;
    bool Check(SAntiCheatResult& out) override;
    void Update(f32 deltaTime) override;

    // ---- 行为数据接入（真实游戏端调用）----
    void ReportBehavior(const SBehaviorSample& sample);

    // ---- 云端 LLM 分析服务配置 ----
    void SetLLMEndpoint(const std::string& url) { m_endpoint = url; }
    void SetEnableDemo(bool enabled) { m_demoEnabled = enabled; }
    void SetReportIntervalSec(float sec) { m_reportInterval = (sec > 0.2f ? sec : 0.2f); }

    // ---- 本地兜底阈值（降级时用）----
    void SetSpeedThreshold(float v) { m_speedThreshold = v; }
    void SetReactionThresholdMs(float ms) { m_reactionThresholdMs = ms; }
    void SetAimThreshold(float v) { m_aimThreshold = v; }

    // ---- 查询（供 HUD/回调展示）----
    bool IsCloudReachable() const noexcept { return m_cloudReachable; }
    const SAIVerdict& GetLastVerdict() const noexcept { return m_lastVerdict; }
    int GetReportedCount() const noexcept { return m_reportedCount; }

private:
    void SendPlayerToCloud(const std::string& playerId);
    void LocalFallback(const SBehaviorSample& avg, SAIVerdict& out);
    void DemoUpdate(f32 deltaTime);
    SBehaviorSample WindowAverage(const std::deque<SBehaviorSample>& w) const;

    std::string m_endpoint;                       // 云端 LLM 分析服务地址
    std::map<std::string, std::deque<SBehaviorSample>> m_players;  // 每个玩家独立行为窗口
    std::map<std::string, SAIVerdict> m_verdicts; // 每个玩家最近判定
    float m_accumulator = 0.f;                    // 上报计时
    float m_reportInterval = 2.0f;                // 上报间隔(秒)
    float m_speedThreshold = 25.f;                // 速度兜底阈值 m/s
    float m_reactionThresholdMs = 90.f;           // 反应兜底阈值 ms
    float m_aimThreshold = 0.985f;                // 瞄准兜底阈值
    bool m_demoEnabled = true;                    // 内置模拟玩家演示
    bool m_cloudReachable = false;                // 云端是否可达
    bool m_demoStarted = false;
    float m_demoTimer = 0.f;
    float m_demoSampleTimer = 0.f;
    int m_reportedCount = 0;
    SAIVerdict m_lastVerdict;                     // 最近一次判定（供 HUD/回调展示）
};

} // namespace MFS::CoreLock
