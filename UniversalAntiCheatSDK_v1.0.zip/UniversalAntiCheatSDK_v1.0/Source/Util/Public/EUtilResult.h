﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"

namespace MFS::CoreLock {

enum class EUtilResult : uint32_t
{
    Success = 0,
    Failure,
    InvalidParam,
    OutOfMemory,
    FileNotFound,
    FileReadError,
    FileWriteError,
    FileExists,
    InvalidFormat,
    Unsupported,
    Timeout,
    Cancelled,
    AccessDenied,
    NetworkError,
    DataCorrupted,
    BufferOverflow,
    InternalError,
    NotImplemented
};

const char* UtilResultToString(EUtilResult result);

} // namespace MFS::CoreLock