﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/ILog/ILog.h"

#include <string>
#include <fstream>
#include <mutex>

namespace MFS::CoreLock {

/**
 * @brief 日志管理器实现类
 * 
 * 实现 ILog 接口，提供控制台和文件输出功能。
 * 继承 CSingleton 和 IFeature，作为单例模块存在。
 */
class CLogManager : public CSingleton<CLogManager>, public ILog, public IFeature
{
public:
    /**
     * @brief 构造函数
     */
    CLogManager() noexcept;

    /**
     * @brief 析构函数
     */
    virtual ~CLogManager() noexcept;

    void Trace(const std::string& message, const char* file = nullptr, uint32_t line = 0) override;
    void Debug(const std::string& message, const char* file = nullptr, uint32_t line = 0) override;
    void Info(const std::string& message, const char* file = nullptr, uint32_t line = 0) override;
    void Warning(const std::string& message, const char* file = nullptr, uint32_t line = 0) override;
    void Error(const std::string& message, const char* file = nullptr, uint32_t line = 0) override;
    void Critical(const std::string& message, const char* file = nullptr, uint32_t line = 0) override;
    void SetFilterLevel(ELogLevel level) override;
    ELogLevel GetFilterLevel() const override;
    void SetConsoleOutput(bool enable) override;
    void SetFileOutput(bool enable) override;
    void SetLogFilePath(const std::string& path) override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

private:
    CORE_NO_COPY_MOVE(CLogManager);

    /**
     * @brief 输出日志到控制台
     * 
     * @param level 日志级别
     * @param message 日志消息
     * @param file 源文件名称
     * @param line 行号
     */
    void OutputToConsole(ELogLevel level, const std::string& message, 
                         const char* file = nullptr, uint32_t line = 0);

    /**
     * @brief 输出日志到文件
     * 
     * @param level 日志级别
     * @param message 日志消息
     * @param file 源文件名称
     * @param line 行号
     */
    void OutputToFile(ELogLevel level, const std::string& message, 
                      const char* file = nullptr, uint32_t line = 0);

    /**
     * @brief 格式化日志消息
     * 
     * @param level 日志级别
     * @param message 日志消息
     * @param file 源文件名称
     * @param line 行号
     * @return 格式化后的日志字符串
     */
    std::string FormatMessage(ELogLevel level, const std::string& message, 
                              const char* file = nullptr, uint32_t line = 0);

    /**
     * @brief 获取当前时间字符串
     * 
     * @return 格式化的时间字符串
     */
    std::string GetCurrentTimeString();

    /**
     * @brief 日志过滤级别
     */
    ELogLevel m_filterLevel;

    /**
     * @brief 是否输出到控制台
     */
    bool m_consoleOutput;

    /**
     * @brief 是否输出到文件
     */
    bool m_fileOutput;

    /**
     * @brief 日志文件路径
     */
    std::string m_logFilePath;

    /**
     * @brief 日志文件流
     */
    std::ofstream m_logFile;

    /**
     * @brief 线程安全互斥锁
     */
    mutable std::mutex m_mutex;

    /**
     * @brief 模块生命周期状态
     */
    EFeatureState m_featureState;
};

} // namespace MFS::CoreLock