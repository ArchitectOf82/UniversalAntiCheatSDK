﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"

#include <string>
#include <vector>
#include <map>
#include <functional>

namespace MFS::CoreLock {

/**
 * @brief 自毁阶段
 */
enum class EDestructPhase
{
    Idle = 0,           ///< 空闲
    SilentWipe,         ///< 静默清除关键内存数据
    ArchitectureCollapse, ///< 架构坍塌（断开服务连接）
    CodeErasure,        ///< 代码断层清除（替换代码节）
    FinalTermination,   ///< 最终终止
    Completed           ///< 已完成
};

/**
 * @brief 关键内存区域描述
 */
struct SCriticalMemoryRegion
{
    std::string name;           ///< 区域名称
    uint8_t* address;                ///< 起始地址
    uint64_t size;                   ///< 区域大小
    bool isWiped;               ///< 是否已清除
    uint32_t originalCRC;            ///< 原始CRC校验值
};

/**
 * @brief 服务连接节点描述（用于架构坍塌）
 */
struct SServiceNode
{
    std::string serviceName;    ///< 服务名称
    uint32_t nodeId;                 ///< 节点ID
    std::vector<uint32_t> connections; ///< 连接的其他节点ID
    bool isCollapsed;           ///< 是否已坍塌
    uint64_t collapseTime;           ///< 坍塌时间戳
};

/**
 * @brief 代码节描述（用于代码断层清除）
 */
struct SCodeSegment
{
    std::string name;           ///< 节名称
    uint8_t* startAddress;           ///< 起始地址
    uint64_t size;                   ///< 节大小
    bool isErased;              ///< 是否已清除
    uint64_t erasureTime;            ///< 清除时间戳
};

/**
 * @brief 自毁事件回调类型
 */
using DestructCallback = std::function<void(EDestructPhase phase)>;

/**
 * @brief 静默自毁系统
 *
 * 检测到篡改时静默清除关键内存数据（不弹窗不报错）。
 * 架构坍塌：逐步破坏服务间连接，使集群瓦解。
 * 代码断层清除：将代码节内容替换为随机字节，防止逆向。
 * 默认静默模式：不给攻击者任何提示。
 */
class CStealthSelfDestruct : public IFeature, public CSingleton<CStealthSelfDestruct>
{
public:
    CStealthSelfDestruct() noexcept;
    ~CStealthSelfDestruct() noexcept override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    /**
     * @brief 触发静默自毁
     * 静默清除关键内存数据，不弹窗不报错
     * @return true=触发成功
     */
    bool TriggerSelfDestruct();

    /**
     * @brief 触发架构坍塌
     * 逐步破坏服务间连接，使集群瓦解
     * @return true=触发成功
     */
    bool TriggerArchitectureCollapse();

    /**
     * @brief 触发代码断层清除
     * 将代码节内容替换为随机字节，防止逆向
     * @return true=触发成功
     */
    bool TriggerCodeErasure();

    /**
     * @brief 设置静默模式
     * @param silent true=静默模式（默认），不给出任何提示
     */
    void SetSilentMode(bool silent);

    /**
     * @brief 是否处于静默模式
     */
    bool IsSilentMode() const;

    /**
     * @brief 注册关键内存区域
     * @param name 区域名称
     * @param address 起始地址
     * @param size 大小
     * @return true=注册成功
     */
    bool RegisterCriticalRegion(const std::string& name, uint8_t* address, uint64_t size);

    /**
     * @brief 注册服务节点（用于架构坍塌）
     * @param serviceName 服务名称
     * @param connectedNodeIds 连接的节点ID列表
     * @return 分配的节点ID
     */
    uint32_t RegisterServiceNode(const std::string& serviceName, const std::vector<uint32_t>& connectedNodeIds);

    /**
     * @brief 注册代码节（用于代码断层清除）
     */
    bool RegisterCodeSegment(const std::string& name, uint8_t* startAddress, uint64_t size);

    /**
     * @brief 获取当前自毁阶段
     */
    EDestructPhase GetDestructPhase() const;

    /**
     * @brief 是否已触发自毁
     */
    bool IsDestructTriggered() const;

    /**
     * @brief 设置自毁事件回调
     */
    void SetDestructCallback(DestructCallback callback);

    /**
     * @brief 获取已清除的内存区域数量
     */
    uint32_t GetWipedRegionCount() const;

    /**
     * @brief 获取已坍塌的服务节点数量
     */
    uint32_t GetCollapsedNodeCount() const;

    /**
     * @brief 获取已清除的代码节数量
     */
    uint32_t GetErasedSegmentCount() const;

private:
    CORE_NO_COPY_MOVE(CStealthSelfDestruct);

    /**
     * @brief 静默清除单个内存区域
     * 用零字节覆盖内存内容
     */
    bool WipeMemoryRegion(SCriticalMemoryRegion& region);

    /**
     * @brief 坍塌单个服务节点
     * 断开该节点与其他节点的所有连接
     */
    bool CollapseServiceNode(SServiceNode& node);

    /**
     * @brief 清除单个代码节
     * 将代码节内容替换为随机字节
     */
    bool EraseCodeSegment(SCodeSegment& segment);

    /**
     * @brief 生成随机字节填充缓冲区
     */
    void FillRandomBytes(uint8_t* buffer, uint64_t size);

    /**
     * @brief 计算CRC32校验值
     */
    uint32_t CalculateCRC32(const uint8_t* data, uint64_t size);

    /**
     * @brief 获取当前时间戳
     */
    uint64_t GetCurrentTimestamp() const;

    /**
     * @brief 推进自毁流程
     */
    void AdvanceDestructPhase();

    EFeatureState m_state;
    EDestructPhase m_destructPhase;
    bool m_silentMode;
    bool m_destructTriggered;
    uint64_t m_phaseStartTime;
    uint32_t m_nextServiceNodeId;
    DestructCallback m_destructCallback;

    std::vector<SCriticalMemoryRegion> m_criticalRegions;
    std::map<uint32_t, SServiceNode> m_serviceNodes;
    std::vector<SCodeSegment> m_codeSegments;

    uint32_t m_wipedCount;
    uint32_t m_collapsedCount;
    uint32_t m_erasedCount;
};

} // namespace MFS::CoreLock
