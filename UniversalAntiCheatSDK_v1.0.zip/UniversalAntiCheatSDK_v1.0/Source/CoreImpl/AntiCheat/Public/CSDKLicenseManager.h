﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"

#include <string>
#include <vector>
#include <map>

namespace MFS::CoreLock {

enum class ELicenseStatus
{
    Unknown,
    Valid,
    Invalid,
    Expired,
    NotActivated,
    HardwareMismatch,
    Trial,
    TrialExpired,
    Suspended
};

enum class ELicenseType
{
    Unknown,
    Trial,
    Personal,
    Commercial,
    Enterprise,
    Developer
};

struct SLicenseInfo
{
    std::string licenseKey;
    ELicenseType licenseType;
    ELicenseStatus status;
    std::string hardwareId;
    std::string ownerName;
    std::string email;
    uint64_t issueDate;
    uint64_t expireDate;
    uint64_t activationDate;
    std::string productVersion;
    std::vector<std::string> allowedModules;
    bool isActivated;
};

class CSDKLicenseManager : public IFeature, public CSingleton<CSDKLicenseManager>
{
public:
    CSDKLicenseManager() noexcept;
    ~CSDKLicenseManager() noexcept override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    bool ActivateLicense(const std::string& licenseKey, const std::string& hardwareId);
    bool ValidateLicense(const std::string& licenseKey);
    ELicenseStatus CheckLicenseStatus();
    bool DeactivateLicense();

    bool IsLicenseValid() const;
    bool IsTrial() const;
    bool IsExpired() const;
    f32 GetRemainingDays() const;
    uint64_t GetRemainingSeconds() const;

    const SLicenseInfo& GetLicenseInfo() const;
    ELicenseType GetLicenseType() const;
    const std::string& GetLicenseKey() const;

    bool CheckModuleAccess(const std::string& moduleName) const;
    bool SetAllowedModules(const std::vector<std::string>& modules);

private:
    CORE_NO_COPY_MOVE(CSDKLicenseManager);

    bool LoadLicenseFromFile();
    bool SaveLicenseToFile();
    bool GenerateLicenseSignature(const std::string& licenseKey, std::string& outSignature);
    bool ValidateLicenseSignature(const std::string& licenseKey, const std::string& signature);
    bool DecryptLicenseData(const std::string& encryptedData, SLicenseInfo& outInfo);
    bool EncryptLicenseData(const SLicenseInfo& info, std::string& outData);

    std::string GenerateActivationCode(const std::string& licenseKey, const std::string& hardwareId);
    bool VerifyActivationCode(const std::string& licenseKey, const std::string& hardwareId, const std::string& activationCode);

    EFeatureState m_state;
    SLicenseInfo m_licenseInfo;
    std::string m_licenseFilePath;
    bool m_isActivated;
    uint64_t m_lastCheckTime;
};

} // namespace MFS::CoreLock
