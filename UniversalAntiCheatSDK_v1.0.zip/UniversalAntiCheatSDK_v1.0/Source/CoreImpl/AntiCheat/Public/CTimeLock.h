﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"

#include <string>
#include <vector>
#include <functional>

namespace MFS::CoreLock {

enum class ETimeLockStatus
{
    Unknown,
    NotStarted,
    Running,
    Paused,
    Expired,
    Terminated
};

struct STimeLockInfo
{
    std::string lockId;
    ETimeLockStatus status;
    uint64_t startTime;
    uint64_t endTime;
    uint64_t totalDuration;
    uint64_t elapsedTime;
    uint64_t remainingTime;
    bool isPaused;
    bool isExpired;
    std::string productName;
    std::string version;
    uint64_t lastCheckTime;
};

class CTimeLock : public IFeature, public CSingleton<CTimeLock>
{
public:
    CTimeLock() noexcept;
    ~CTimeLock() noexcept override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    bool StartTrial(uint64_t durationSeconds);
    bool StartSubscription(uint64_t durationSeconds);
    bool Pause();
    bool Resume();
    bool Terminate();

    ETimeLockStatus GetStatus() const;
    uint64_t GetRemainingTime() const;
    uint64_t GetElapsedTime() const;
    f32 GetRemainingDays() const;
    f32 GetProgress() const;

    bool IsExpired() const;
    bool IsRunning() const;
    bool IsPaused() const;

    bool SetExpirationCallback(std::function<void()> callback);
    bool SetWarningCallback(std::function<void(uint64_t remainingSeconds)> callback);
    bool SetWarningThreshold(uint64_t secondsBeforeExpiration);

    bool CheckTimeManipulation();
    bool VerifySystemTime();

    bool LoadTimeLockState();
    bool SaveTimeLockState();

private:
    CORE_NO_COPY_MOVE(CTimeLock);

    void OnExpiration();
    void OnWarning(uint64_t remainingSeconds);
    
    bool EncryptTimeData(const STimeLockInfo& info, std::string& outData);
    bool DecryptTimeData(const std::string& encryptedData, STimeLockInfo& outInfo);

    EFeatureState m_state;
    STimeLockInfo m_timeLockInfo;
    std::function<void()> m_expirationCallback;
    std::function<void(uint64_t)> m_warningCallback;
    uint64_t m_warningThreshold;
    bool m_warningTriggered;
    std::string m_stateFilePath;
};

} // namespace MFS::CoreLock
