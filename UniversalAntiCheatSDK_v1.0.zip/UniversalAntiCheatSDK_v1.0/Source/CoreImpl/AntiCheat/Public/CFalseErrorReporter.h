﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"

#include <string>
#include <vector>

namespace MFS::CoreLock {

/**
 * @brief 假错误类型分类
 *
 * 伪装成普通运行时错误，使攻击者无法判断真实原因。
 */
enum class EFalseErrorType
{
    OutOfMemory = 0,        ///< 内存不足
    NetworkTimeout,         ///< 网络超时
    AccessViolation,        ///< 访问违规
    StackOverflow,          ///< 栈溢出
    DiskFull,               ///< 磁盘空间不足
    FileNotFound,           ///< 文件未找到
    PermissionDenied,       ///< 权限被拒绝
    ConnectionReset,        ///< 连接被重置
    HeapCorruption,         ///< 堆损坏
    Timeout,                ///< 操作超时
    InvalidParameter,       ///< 无效参数
    SystemCallFailed        ///< 系统调用失败
};

/**
 * @brief 假错误模板结构
 */
struct SFalseErrorTemplate
{
    EFalseErrorType type;        ///< 错误类型
    uint32_t errorCode;               ///< 伪装的错误码
    std::string title;           ///< 错误标题
    std::string message;         ///< 错误消息内容
    std::string detail;          ///< 错误详情
    uint32_t severity;                ///< 严重程度（0-100）
};

/**
 * @brief 已报告的假错误记录
 */
struct SFalseErrorRecord
{
    EFalseErrorType type;        ///< 错误类型
    uint32_t errorCode;               ///< 错误码
    std::string fullMessage;     ///< 完整错误消息
    uint64_t timestamp;               ///< 报告时间戳
    uint32_t reportCount;             ///< 该错误已报告次数
};

/**
 * @brief 错误信息欺骗系统
 *
 * 检测到攻击时返回误导性错误信息。
 * 伪装成普通运行时错误（内存不足、网络超时等）。
 * 随机选择假错误模板，使攻击者无法判断真实原因。
 */
class CFalseErrorReporter : public IFeature, public CSingleton<CFalseErrorReporter>
{
public:
    CFalseErrorReporter() noexcept;
    ~CFalseErrorReporter() noexcept override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    /**
     * @brief 报告假错误
     * 当检测到攻击行为时，返回误导性错误信息
     * @param type 指定的假错误类型（若为随机则自动选择）
     * @return 完整的假错误消息字符串
     */
    std::string ReportFalseError(EFalseErrorType type = static_cast<EFalseErrorType>(0xFFFF));

    /**
     * @brief 获取一个随机假错误模板
     * @return 随机选择的假错误模板
     */
    SFalseErrorTemplate GetRandomFalseError() const;

    /**
     * @brief 获取指定类型的假错误模板
     * @param type 错误类型
     * @return 对应的假错误模板
     */
    SFalseErrorTemplate GetFalseErrorByType(EFalseErrorType type) const;

    /**
     * @brief 获取已报告的假错误历史记录
     */
    const std::vector<SFalseErrorRecord>& GetErrorHistory() const;

    /**
     * @brief 获取假错误报告总数
     */
    uint32_t GetTotalReportCount() const;

    /**
     * @brief 设置是否启用随机错误码偏移
     * 启用后每次报告的错误码会有微小随机偏移，增加迷惑性
     */
    void SetRandomCodeOffset(bool enabled);

    /**
     * @brief 获取假错误模板总数
     */
    uint32_t GetTemplateCount() const;

    /**
     * @brief 清除错误历史记录
     */
    void ClearHistory();

private:
    CORE_NO_COPY_MOVE(CFalseErrorReporter);

    /**
     * @brief 初始化所有假错误模板
     */
    void InitTemplates();

    /**
     * @brief 生成带随机偏移的错误码
     */
    uint32_t GenerateErrorCode(uint32_t baseCode) const;

    /**
     * @brief 格式化完整错误消息
     */
    std::string FormatErrorMessage(const SFalseErrorTemplate& tmpl, uint32_t errorCode) const;

    /**
     * @brief 获取当前时间戳
     */
    uint64_t GetCurrentTimestamp() const;

    /**
     * @brief 伪随机数生成
     */
    uint32_t PseudoRandom(uint32_t seed) const;

    EFeatureState m_state;
    std::vector<SFalseErrorTemplate> m_templates;
    std::vector<SFalseErrorRecord> m_errorHistory;
    uint32_t m_totalReportCount;
    bool m_randomCodeOffset;
    mutable uint32_t m_randomSeed;
};

} // namespace MFS::CoreLock
