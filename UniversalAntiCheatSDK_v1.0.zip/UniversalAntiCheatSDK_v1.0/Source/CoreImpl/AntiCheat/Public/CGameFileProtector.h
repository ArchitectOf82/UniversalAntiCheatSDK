﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "Source/Util/Public/EUtilResult.h"

#include <windows.h>
#include <string>
#include <vector>
#include <map>

namespace MFS::CoreLock {

/**
 * @class CGameFileProtector
 * @brief 游戏文件保护器（内层 / Game 层）
 *
 * 职责边界（内层 Game）：
 * - 游戏配置 / 存档文件的完整性校验（哈希）
 * - 游戏文件锁（防止被其他进程占用）
 * - 只读属性控制
 * - 所有文件操作结果返回 EUtilResult（内层专用）
 *
 * 与外层 CFileProtector 的区别：
 * - 外层（引擎保护）：核心引擎文件的哈希校验 + 锁文件 + 只读
 * - 内层（游戏反作弊）：游戏数据文件的完整性监控，返回 EUtilResult
 *
 * 两层各自独立命名空间，同名不同实现，链接器不冲突。
 */
struct ProtectedFileInfo
{
    std::string filePath;
    uint64_t originalHash;
    bool isLocked;
    bool isReadOnly;
    HANDLE hFile;
};

class CGameFileProtector
{
public:
    CGameFileProtector() noexcept;
    ~CGameFileProtector() noexcept;

    bool AddProtectedFile(const std::string& filePath, bool lockFile = true, bool setReadOnly = true);
    bool RemoveProtectedFile(const std::string& filePath);
    bool ProtectAllFiles();
    bool UnprotectAllFiles();

    bool CheckFileIntegrity(const std::string& filePath);
    bool CheckAllFilesIntegrity();

    EUtilResult LockFile(const std::string& filePath);
    EUtilResult UnlockFile(const std::string& filePath);

    bool SetFileReadOnly(const std::string& filePath, bool readOnly);

    uint64_t CalculateFileHash(const std::string& filePath);

    size_t GetProtectedFileCount() const noexcept;
    const std::map<std::string, ProtectedFileInfo>& GetProtectedFiles() const noexcept;

private:
    CORE_NO_COPY_MOVE(CGameFileProtector);

    bool LockFileByHandle(const std::string& filePath, HANDLE& outHandle);
    bool UnlockFileByHandle(HANDLE hFile);

    std::map<std::string, ProtectedFileInfo> m_protectedFiles;
};

} // namespace MFS::CoreLock
