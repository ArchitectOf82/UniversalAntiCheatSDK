﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"

#include <string>
#include <vector>
#include <functional>
#include <memory>

namespace MFS::CoreLock {

/**
 * 反作弊检查结果
 */
struct SAntiCheatResult
{
    bool passed;
    std::string checkName;
    std::string reason;
    f32 severity;  // 0.0 (info) ~ 1.0 (critical)
};

/**
 * 自定义反作弊模块接口
 * 游戏开发者可继承此接口实现自己的反作弊逻辑
 *
 * 使用示例：
 *   class CWallhackDetector : public IAntiCheatModule {
 *       bool Check(SAntiCheatResult& outResult) override {
 *           // 检测透视外挂...
 *           outResult.passed = !detected;
 *           outResult.checkName = "WallhackDetector";
 *           outResult.severity = 0.9f;
 *           return outResult.passed;
 *       }
 *   };
 */
class IAntiCheatModule
{
public:
    virtual ~IAntiCheatModule() noexcept = default;

    /**
     * 获取模块名称
     */
    virtual const char* GetName() const = 0;

    /**
     * 执行反作弊检查
     * @param outResult 输出检查结果
     * @return true=通过, false=检测到作弊
     */
    virtual bool Check(SAntiCheatResult& outResult) = 0;

    /**
     * 每帧更新（可选重写，默认空实现）
     */
    virtual void Update(f32 deltaTime) {}

    /**
     * 初始化（可选重写）
     */
    virtual void Initialize() {}

    /**
     * 关闭（可选重写）
     */
    virtual void Shutdown() {}

    /**
     * 是否启用
     */
    bool IsEnabled() const { return m_enabled; }
    void SetEnabled(bool enabled) { m_enabled = enabled; }

protected:
    bool m_enabled = true;
};

/**
 * 反作弊配置
 */
struct SAntiCheatConfig
{
    bool enableAntiDebug = true;
    bool enableIntegrityCheck = true;
    bool enableHardwareBinding = true;
    bool enableTimeLock = true;
    bool enableOnlineValidation = false;
    bool enableSpeedHackCheck = true;
    bool enableMemoryScan = true;
    uint32_t checkIntervalMs = 100;  // 检查间隔
    f32 violationThreshold = 0.8f;  // 违规阈值
};

/**
 * 反作弊事件回调
 */
using AntiCheatCallback = std::function<void(const SAntiCheatResult& result)>;

} // namespace MFS::CoreLock
