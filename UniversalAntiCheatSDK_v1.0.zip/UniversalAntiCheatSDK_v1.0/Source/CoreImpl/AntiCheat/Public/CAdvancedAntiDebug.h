﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"

#include <string>
#include <vector>

namespace MFS::CoreLock {

enum class EAntiDebugCheck
{
    None,
    DebuggerPresent,
    HardwareBreakpoints,
    SoftwareBreakpoints,
    CodeInjection,
    MemoryPatching,
    VirtualMachine,
    Emulator,
    HookDetection,
    ProcessTampering,
    TimerSpoofing
};

struct SAntiDebugResult
{
    EAntiDebugCheck checkType;
    bool detected;
    std::string description;
    uint64_t timestamp;
};

class CAdvancedAntiDebug : public IFeature, public CSingleton<CAdvancedAntiDebug>
{
public:
    CAdvancedAntiDebug() noexcept;
    ~CAdvancedAntiDebug() noexcept override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    bool CheckDebugger() const;
    bool CheckHardwareBreakpoints() const;
    bool CheckSoftwareBreakpoints() const;
    bool CheckCodeInjection() const;
    bool CheckMemoryPatching() const;
    bool CheckVirtualMachine() const;
    bool CheckEmulator() const;
    bool CheckHookDetection() const;
    bool CheckProcessTampering() const;
    bool CheckTimerSpoofing() const;

    bool RunAllChecks();
    const std::vector<SAntiDebugResult>& GetDetectionResults() const;

    void SetDetectionAction(bool terminateOnDetection);
    bool GetDetectionAction() const;

    void StartBackgroundMonitoring();
    void StopBackgroundMonitoring();
    bool IsMonitoring() const;

private:
    CORE_NO_COPY_MOVE(CAdvancedAntiDebug);

    bool CheckDrRegisters() const;
    bool CheckDebugPort() const;
    bool CheckParentProcess() const;
    bool CheckProcessDebugFlags() const;
    bool CheckNtGlobalFlag() const;
    bool CheckIsDebuggerPresent() const;
    bool CheckOutputDebugString() const;
    bool CheckHardwareBreakpointDR() const;

    bool CheckVMArtifacts() const;
    bool CheckEmulatorArtifacts() const;
    bool CheckRDTSCInconsistency() const;

    bool CheckInjectedThreads() const;
    bool CheckUnusualMemoryRegions() const;
    bool CheckModuleInjection() const;

    bool CheckHookedFunctions() const;
    bool CheckIATModifications() const;
    bool CheckEATModifications() const;

    void OnDetection(EAntiDebugCheck checkType, const std::string& description);
    void TerminateOnDetection();

    EFeatureState m_state;
    std::vector<SAntiDebugResult> m_detectionResults;
    bool m_terminateOnDetection;
    bool m_isMonitoring;
    uint64_t m_lastCheckTime;
};

} // namespace MFS::CoreLock
