﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"

#include "CSDKLicenseManager.h"
#include "CCodeIntegrity.h"
#include "CAdvancedAntiDebug.h"
#include "CHardwareFingerprint.h"
#include "CTimeLock.h"
#include "COnlineActivation.h"
#include "CDynamicMazeGuard.h"
#include "CStealthSelfDestruct.h"
#include "CFalseErrorReporter.h"
#include "CBase128Obfuscation.h"

#include <string>
#include <vector>
#include <functional>

namespace MFS::CoreLock {

/**
 * @class CSDKProtectionManager
 * @brief SDK 安全总控（内层 / Game 层）
 *
 * 整合内层所有安全子系统：
 * - CGameAntiCheatKernel  → 游戏进程级 debugger / 加速检测
 * - CGameAntiCheatMemory  → 游戏内存完整性监控
 * - CGameAntiCheatLearn   → 游戏行为学习（BOT 检测）
 * - CGameFileProtector    → 游戏文件完整性校验
 * - CSDKLicenseManager    → 授权管理
 * - CCodeIntegrity        → 代码节完整性
 * - CAdvancedAntiDebug     → 高级反调试（内部调用 CGameAntiCheatKernel）
 * - CHardwareFingerprint  → 硬件指纹绑定
 * - CTimeLock             → 时间锁
 * - COnlineActivation      → 在线激活 [缺 .cpp，详见 DEV_GUIDE]
 * - CDynamicMazeGuard      → 五进制动态迷宫 + 诱饵蜜罐
 * - CStealthSelfDestruct   → 静默自毁 + 架构坍塌 + 代码断层清除
 * - CFalseErrorReporter    → 错误信息欺骗（误导攻击者）
 * - CBase128Obfuscation    → 128进制反调试 + 数据混淆
 *
 * 与外层 CAntiCheatHub 的关系：
 * - 外层（引擎保护）：引擎级安全总控，注册 IAntiCheatModule 接口
 * - 内层（SDK 安全）：SDK 授权 + 游戏行为反作弊总控
 * - 两层独立初始化，CAntiCheatHub 初始化时构建栈上 kernel 临时对象（外层）
 * - CSDKProtectionManager 由 CCoreLockSDK 单独实例化（内层）
 */
enum class ESPProtectionStatus
{
    Unknown,
    NotInitialized,
    Initializing,
    Running,
    SecurityViolation,
    LicenseExpired,
    TrialMode,
    ValidationFailed
};

struct SProtectionSummary
{
    ESPProtectionStatus overallStatus;
    bool licenseValid;
    bool integrityCheckPassed;
    bool antiDebugCheckPassed;
    bool hardwareVerified;
    bool timeLockActive;
    bool onlineValidationPassed;
    std::string machineId;
    std::string licenseType;
    uint64_t remainingDays;
    std::vector<std::string> activeModules;
};

class CSDKProtectionManager : public IFeature, public CSingleton<CSDKProtectionManager>
{
public:
    CSDKProtectionManager() noexcept;
    ~CSDKProtectionManager() noexcept override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    bool ActivateSDK(const std::string& licenseKey);
    bool ValidateSDK();
    bool CheckAccess(const std::string& moduleName) const;

    ESPProtectionStatus GetProtectionStatus() const;
    const SProtectionSummary& GetProtectionSummary() const;

    bool StartTrialMode(uint64_t durationDays = 30);
    bool IsTrialMode() const;
    f32 GetRemainingTrialDays() const;

    bool EnableAntiDebug(bool enable);
    bool EnableIntegrityCheck(bool enable);
    bool EnableHardwareBinding(bool enable);
    bool EnableTimeLock(bool enable);
    bool EnableOnlineValidation(bool enable);

    // ===== 高级保护机制 =====
    bool EnableDynamicMaze(bool enable);
    bool EnableSelfDestruct(bool enable);
    bool EnableFalseErrorReporting(bool enable);
    bool EnableBase128Obfuscation(bool enable);

    /// @brief 触发紧急自毁（检测到严重安全违规时调用）
    void TriggerEmergencySelfDestruct();

    /// @brief 部署蜜罐诱饵
    void DeployHoneypots();

    void StartBackgroundSecurityMonitoring();
    void StopBackgroundSecurityMonitoring();

    bool SetSecurityViolationCallback(std::function<void(const std::string& reason)> callback);

private:
    CORE_NO_COPY_MOVE(CSDKProtectionManager);

    void UpdateProtectionSummary();
    void OnSecurityViolation(const std::string& reason);

    bool PerformInitialSecurityChecks();
    bool PerformRuntimeSecurityChecks();

    EFeatureState m_state;
    ESPProtectionStatus m_protectionStatus;
    SProtectionSummary m_protectionSummary;

    CSDKLicenseManager m_licenseManager;
    CCodeIntegrity m_codeIntegrity;
    CAdvancedAntiDebug m_antiDebug;
    CHardwareFingerprint m_hardwareFingerprint;
    CTimeLock m_timeLock;
    COnlineActivation m_onlineActivation;

    // 高级保护子系统
    CDynamicMazeGuard m_dynamicMaze;
    CStealthSelfDestruct m_selfDestruct;
    CFalseErrorReporter m_falseErrorReporter;
    CBase128Obfuscation m_base128Obfuscation;

    bool m_antiDebugEnabled;
    bool m_integrityCheckEnabled;
    bool m_hardwareBindingEnabled;
    bool m_timeLockEnabled;
    bool m_onlineValidationEnabled;
    bool m_dynamicMazeEnabled;
    bool m_selfDestructEnabled;
    bool m_falseErrorEnabled;
    bool m_base128Enabled;

    std::function<void(const std::string& reason)> m_securityCallback;
    bool m_isMonitoring;
    // 最近一次安全检查结果（用于状态摘要，避免硬编码 true）
    bool m_lastAntiDebugPassed;
    bool m_lastIntegrityPassed;
};

} // namespace MFS::CoreLock
