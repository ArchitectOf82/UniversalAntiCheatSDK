﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"

#include <string>
#include <vector>
#include <map>
#include <functional>

namespace MFS::CoreLock {

/**
 * @brief 五叉树迷宫节点类型
 *
 * 每个节点拥有五条分支路径，构成五进制动态迷宫。
 * 攻击者进入后会在死循环路径中迷失方向。
 */
enum class EMazeNodeType
{
    Invalid = 0,
    Entry,          ///< 迷宫入口节点
    Branch,         ///< 分支节点（五条子路径）
    Decoy,          ///< 诱饵节点（看似关键实则陷阱）
    DeadEnd,        ///< 死胡同节点（循环陷阱）
    Exit,           ///< 真实出口节点
    Honeypot        ///< 蜜罐节点（诱饵函数集合）
};

/**
 * @brief 蜜罐函数类型
 *
 * 伪装成关键功能的诱饵函数，吸引攻击者注意力。
 */
enum class EHoneypotType
{
    FakeLicenseCheck,   ///< 伪造的许可证校验
    FakeKeyVerify,      ///< 伪造的密钥验证
    FakeCryptoInit,     ///< 伪造的加密初始化
    FakeNetworkAuth,    ///< 伪造的网络认证
    FakeIntegrityCheck  ///< 伪造的完整性检查
};

/**
 * @brief 五叉树迷宫节点结构
 */
struct SMazeNode
{
    uint32_t nodeId;                 ///< 节点唯一标识
    EMazeNodeType type;         ///< 节点类型
    uint32_t children[5];            ///< 五条子路径节点ID（0表示无子节点）
    uint32_t parent;                 ///< 父节点ID
    uint32_t depth;                  ///< 迷宫深度
    bool isTrap;                ///< 是否为陷阱节点
    bool visited;               ///< 是否已被访问
    std::string decoyName;      ///< 诱饵节点伪装名称
    uint64_t seed;                   ///< 节点随机种子
};

/**
 * @brief 蜜罐函数描述结构
 */
struct SHoneypot
{
    uint32_t honeypotId;             ///< 蜜罐唯一标识
    EHoneypotType type;         ///< 蜜罐类型
    std::string fakeName;       ///< 伪装函数名
    std::string fakeSymbol;     ///< 伪装符号导出名
    uint8_t* fakeEntryAddress;       ///< 伪造入口地址
    uint32_t mazeNodeId;             ///< 所属迷宫节点ID
    bool isDeployed;            ///< 是否已部署
    uint64_t deploymentTime;         ///< 部署时间戳
};

/**
 * @brief 迷宫会话状态结构
 */
struct SMazeSession
{
    uint32_t sessionId;              ///< 会话ID
    uint32_t currentNodeId;          ///< 当前所在节点
    uint32_t entryNodeId;            ///< 入口节点
    uint32_t exitNodeId;             ///< 出口节点
    bool isTrapped;             ///< 是否被困
    uint32_t stepsTaken;             ///< 已走步数
    uint64_t entryTime;              ///< 进入时间戳
    uint64_t lastPathSwitchTime;     ///< 上次路径切换时间
};

/**
 * @brief 五进制动态迷宫守卫
 *
 * 构建五叉树结构的假代码路径迷宫，攻击者进入后被困在死循环。
 * 生成蜜罐函数（看似关键但实际是诱饵的函数）。
 * 运行时随机切换迷宫路径，使静态分析结果无效。
 */
class CDynamicMazeGuard : public IFeature, public CSingleton<CDynamicMazeGuard>
{
public:
    CDynamicMazeGuard() noexcept;
    ~CDynamicMazeGuard() noexcept override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    /**
     * @brief 进入迷宫
     * @return 迷宫会话ID，0表示进入失败
     */
    uint32_t EnterMaze();

    /**
     * @brief 退出迷宫
     * @param sessionId 会话ID
     * @return true=成功退出, false=仍在迷宫中或会话无效
     */
    bool ExitMaze(uint32_t sessionId);

    /**
     * @brief 检查会话是否被困在迷宫中
     * @param sessionId 会话ID
     * @return true=被困在死循环中
     */
    bool IsTrapped(uint32_t sessionId) const;

    /**
     * @brief 部署蜜罐函数
     * @param count 部署数量
     * @return 实际部署的蜜罐数量
     */
    uint32_t DeployHoneypots(uint32_t count);

    /**
     * @brief 获取所有蜜罐列表
     */
    const std::vector<SHoneypot>& GetHoneypots() const;

    /**
     * @brief 获取迷宫节点总数
     */
    uint32_t GetMazeNodeCount() const;

    /**
     * @brief 获取活跃会话数量
     */
    uint32_t GetActiveSessionCount() const;

    /**
     * @brief 设置路径切换间隔（秒）
     */
    void SetPathSwitchInterval(uint32_t seconds);

    /**
     * @brief 设置是否启用运行时路径切换
     */
    void SetRuntimeSwitchEnabled(bool enabled);

private:
    CORE_NO_COPY_MOVE(CDynamicMazeGuard);

    /**
     * @brief 构建五叉树迷宫
     * @param depth 迷宫深度
     * @return true=构建成功
     */
    bool BuildMazeTree(uint32_t depth);

    /**
     * @brief 创建迷宫节点
     */
    uint32_t CreateNode(EMazeNodeType type, uint32_t parent, uint32_t depth);

    /**
     * @brief 随机化迷宫路径
     * 在运行时随机切换子节点连接关系，使静态分析失效
     */
    void RandomizePaths();

    /**
     * @brief 生成单个蜜罐函数
     */
    bool GenerateHoneypot(SHoneypot& outHoneypot);

    /**
     * @brief 选择下一个节点
     * @param sessionId 会话ID
     * @param branchIndex 分支索引（0-4）
     * @return 下一个节点ID
     */
    uint32_t SelectNextNode(uint32_t sessionId, uint32_t branchIndex);

    /**
     * @brief 生成伪随机数
     */
    uint32_t PseudoRandom(uint32_t seed);

    /**
     * @brief 获取当前时间戳
     */
    uint64_t GetCurrentTimestamp() const;

    /**
     * @brief 清理所有迷宫数据
     */
    void ClearMaze();

    EFeatureState m_state;
    std::map<uint32_t, SMazeNode> m_mazeNodes;       ///< 迷宫节点表
    std::vector<SHoneypot> m_honeypots;         ///< 蜜罐函数列表
    std::map<uint32_t, SMazeSession> m_sessions;     ///< 活跃会话表
    uint32_t m_nextNodeId;                           ///< 下一个节点ID
    uint32_t m_nextSessionId;                        ///< 下一个会话ID
    uint32_t m_nextHoneypotId;                       ///< 下一个蜜罐ID
    uint32_t m_pathSwitchInterval;                   ///< 路径切换间隔（秒）
    bool m_runtimeSwitchEnabled;                ///< 是否启用运行时切换
    uint64_t m_lastSwitchTime;                       ///< 上次路径切换时间戳
    uint32_t m_mazeDepth;                            ///< 迷宫深度
};

} // namespace MFS::CoreLock
