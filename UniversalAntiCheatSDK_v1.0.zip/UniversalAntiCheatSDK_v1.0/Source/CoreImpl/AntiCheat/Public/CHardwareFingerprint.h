﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"

#include <string>
#include <vector>
#include <map>

namespace MFS::CoreLock {

struct SHardwareComponent
{
    std::string componentType;
    std::string vendor;
    std::string model;
    std::string serialNumber;
    std::string uniqueId;
};

struct SHardwareFingerprint
{
    std::string machineId;
    std::string cpuId;
    std::string gpuId;
    std::string motherboardId;
    std::string diskId;
    std::string biosId;
    std::string macAddress;
    std::vector<SHardwareComponent> components;
    uint64_t generationTime;
};

class CHardwareFingerprint : public IFeature, public CSingleton<CHardwareFingerprint>
{
public:
    CHardwareFingerprint() noexcept;
    ~CHardwareFingerprint() noexcept override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    bool GenerateFingerprint();
    const SHardwareFingerprint& GetFingerprint() const;
    const std::string& GetMachineId() const;

    bool VerifyFingerprint(const std::string& storedMachineId);
    bool CheckHardwareChanges();

    bool ExtractCPUInfo();
    bool ExtractGPUInfo();
    bool ExtractMotherboardInfo();
    bool ExtractDiskInfo();
    bool ExtractBIOSInfo();
    bool ExtractNetworkInfo();

    std::string GetCPUId() const;
    std::string GetGPUId() const;
    std::string GetMotherboardId() const;
    std::string GetDiskId() const;

private:
    CORE_NO_COPY_MOVE(CHardwareFingerprint);

    std::string GenerateHashFromComponents();
    std::string ReadRegistryValue(const std::string& key, const std::string& valueName);
    std::string GetVolumeSerialNumber();
    std::string GetMACAddress();

    EFeatureState m_state;
    SHardwareFingerprint m_fingerprint;
    bool m_isGenerated;
};

} // namespace MFS::CoreLock
