﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"

#include <string>
#include <vector>
#include <functional>

namespace MFS::CoreLock {

enum class EActivationStatus
{
    Unknown,
    NotActivated,
    Activated,
    ActivationFailed,
    ServerUnavailable,
    InvalidKey,
    HardwareMismatch,
    Expired,
    Banned,
    Revoked
};

struct SActivationResponse
{
    EActivationStatus status;
    std::string message;
    std::string sessionToken;
    uint64_t expireDate;
    std::string licenseType;
    std::vector<std::string> allowedModules;
};

struct SValidationResponse
{
    bool isValid;
    std::string errorMessage;
    uint64_t remainingDays;
    bool isOnline;
};

class COnlineActivation : public IFeature, public CSingleton<COnlineActivation>
{
public:
    COnlineActivation() noexcept;
    ~COnlineActivation() noexcept override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    SActivationResponse Activate(const std::string& licenseKey, const std::string& hardwareId);
    SValidationResponse Validate(const std::string& licenseKey, const std::string& hardwareId);
    SActivationResponse StartTrial(const std::string& hardwareId);
    bool Deactivate();

    bool IsActivated() const;
    EActivationStatus GetActivationStatus() const;
    bool IsOnline() const;

    bool SetActivationServer(const std::string& serverUrl, uint16_t port = 8080);
    bool SetConnectionTimeout(uint32_t timeoutMs);

    void StartPeriodicValidation(uint32_t intervalSeconds);
    void StopPeriodicValidation();

    bool SetActivationCallback(std::function<void(EActivationStatus)> callback);
    bool SetValidationCallback(std::function<void(SValidationResponse)> callback);

private:
    CORE_NO_COPY_MOVE(COnlineActivation);

    std::string SendRequest(const std::string& endpoint, const std::string& data);
    SActivationResponse ParseActivationResponse(const std::string& json);
    SValidationResponse ParseValidationResponse(const std::string& json);
    
    bool SendHTTPRequest(const std::string& url, const std::string& method, 
                         const std::string& body, std::string& outResponse);

    EFeatureState m_state;
    EActivationStatus m_activationStatus;
    std::string m_serverUrl;
    std::string m_sessionToken;
    uint16_t m_serverPort;
    uint32_t m_connectionTimeout;
    bool m_isOnline;
    bool m_isPeriodicValidationEnabled;
    uint32_t m_validationInterval;
    uint64_t m_lastValidationTime;
    
    std::function<void(EActivationStatus)> m_activationCallback;
    std::function<void(SValidationResponse)> m_validationCallback;
};

} // namespace MFS::CoreLock
