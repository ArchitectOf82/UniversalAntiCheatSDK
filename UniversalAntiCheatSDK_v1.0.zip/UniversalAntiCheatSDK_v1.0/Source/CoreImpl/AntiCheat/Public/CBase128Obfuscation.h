﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"

#include <string>
#include <vector>
#include <map>

namespace MFS::CoreLock {

/**
 * @brief 128进制编码结果
 */
struct SBase128Data
{
    std::vector<uint8_t> encoded;        ///< 编码后的数据
    uint32_t originalSize;               ///< 原始数据大小
    uint64_t encodeTimestamp;            ///< 编码时间戳
};

/**
 * @brief 解码时序检测结果
 */
struct STimingCheckResult
{
    bool debuggerDetected;          ///< 是否检测到调试器
    uint64_t expectedCycles;             ///< 预期CPU周期数
    uint64_t actualCycles;               ///< 实际CPU周期数
    uint64_t cycleDifference;            ///< 周期差值
    f32 timingRatio;                ///< 时间比率（实际/预期）
    uint64_t checkTimestamp;             ///< 检测时间戳
};

/**
 * @brief 128进制反调试混淆系统
 *
 * 将关键字符串和常量编码为128进制，运行时解码。
 * 反调试器通过检查128进制解码时间差来检测调试器。
 * 调试器单步执行会显著增加解码耗时，从而被检测。
 */
class CBase128Obfuscation : public IFeature, public CSingleton<CBase128Obfuscation>
{
public:
    CBase128Obfuscation() noexcept;
    ~CBase128Obfuscation() noexcept override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    /**
     * @brief 将数据编码为128进制
     * @param data 原始数据指针
     * @param size 数据大小
     * @return 编码后的128进制字符串
     */
    std::string Encode128(const uint8_t* data, uint32_t size);

    /**
     * @brief 将字符串编码为128进制
     * @param text 原始字符串
     * @return 编码后的128进制字符串
     */
    std::string Encode128(const std::string& text);

    /**
     * @brief 将128进制编码数据解码为原始字节
     * @param encoded 128进制编码字符串
     * @return 解码后的原始字节数组
     */
    std::vector<uint8_t> Decode128(const std::string& encoded);

    /**
     * @brief 将128进制编码数据解码为字符串
     * @param encoded 128进制编码字符串
     * @return 解码后的原始字符串
     */
    std::string Decode128String(const std::string& encoded);

    /**
     * @brief 检查解码时序以检测调试器
     * 通过测量128进制解码的CPU周期数，判断是否存在调试器
     * @return 时序检测结果
     */
    STimingCheckResult CheckDecodeTiming();

    /**
     * @brief 注册需要保护的编码字符串
     * @param key 字符串键名
     * @param encoded 已编码的128进制数据
     */
    void RegisterEncodedString(const std::string& key, const std::string& encoded);

    /**
     * @brief 获取并解码已注册的字符串
     * @param key 字符串键名
     * @return 解码后的原始字符串
     */
    std::string RetrieveDecodedString(const std::string& key);

    /**
     * @brief 设置时序检测阈值倍数
     * @param multiplier 当实际周期/预期周期超过此值时判定为调试器
     */
    void SetTimingThreshold(f32 multiplier);

    /**
     * @brief 获取最后一次时序检测结果
     */
    const STimingCheckResult& GetLastTimingResult() const;

    /**
     * @brief 获取时序检测历史记录
     */
    const std::vector<STimingCheckResult>& GetTimingHistory() const;

    /**
     * @brief 获取已注册编码字符串数量
     */
    uint32_t GetRegisteredStringCount() const;

    /**
     * @brief 清除所有已注册的编码字符串
     */
    void ClearRegisteredStrings();

private:
    CORE_NO_COPY_MOVE(CBase128Obfuscation);

    /**
     * @brief 获取128进制字符集
     */
    const uint8_t* GetAlphabet() const;

    /**
     * @brief 查找字符在字母表中的索引
     */
    int32_t FindCharIndex(uint8_t ch) const;

    /**
     * @brief 获取CPU时间戳计数器
     */
    uint64_t ReadTSC() const;

    /**
     * @brief 执行校准测量，建立基线周期数
     */
    void CalibrateBaseline();

    /**
     * @brief 获取当前时间戳
     */
    uint64_t GetCurrentTimestamp() const;

    /**
     * @brief 伪随机数生成
     */
    uint32_t PseudoRandom(uint32_t seed) const;

    EFeatureState m_state;
    std::map<std::string, std::string> m_registeredStrings;   ///< 已注册编码字符串
    STimingCheckResult m_lastResult;                          ///< 最近一次检测结果
    std::vector<STimingCheckResult> m_timingHistory;          ///< 检测历史
    uint64_t m_baselineCycles;                                     ///< 基线CPU周期数
    f32 m_timingThreshold;                                    ///< 时序阈值倍数
    uint32_t m_calibrationSize;                                    ///< 校准用数据大小
    std::string m_calibrationEncoded;                         ///< 校准用编码数据
    uint32_t m_randomSeed;
};

} // namespace MFS::CoreLock
