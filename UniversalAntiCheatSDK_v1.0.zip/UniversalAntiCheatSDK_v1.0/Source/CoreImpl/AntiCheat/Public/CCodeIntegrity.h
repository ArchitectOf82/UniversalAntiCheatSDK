﻿#pragma once
#pragma execution_character_set("utf-8")

#include <windows.h>

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/IFeature.h"
#include "CoreInterface/Public/CSingleton/CSingleton.h"

#include <string>
#include <vector>
#include <map>

namespace MFS::CoreLock {

struct SCodeSection
{
    std::string name;
    uint8_t* startAddress;
    uint64_t size;
    uint32_t originalCRC;
    bool isProtected;
};

struct SModuleInfo
{
    std::string moduleName;
    std::string modulePath;
    uint8_t* baseAddress;
    uint64_t moduleSize;
    uint32_t crc32;
    uint64_t fileHash;
    bool isSystemModule;
    bool isTrusted;
};

class CCodeIntegrity : public IFeature, public CSingleton<CCodeIntegrity>
{
public:
    CCodeIntegrity() noexcept;
    ~CCodeIntegrity() noexcept override;

    bool Initialize() override;
    void Update(f32 deltaTime) override;
    void Shutdown() override;
    void GetDependencyList(std::vector<std::string>& outDepList) const override;
    EFeatureState GetState() const noexcept override;

    bool ProtectCodeSection(const std::string& sectionName, uint8_t* startAddr, uint64_t size);
    bool VerifyCodeSection(const std::string& sectionName);
    bool VerifyAllSections();

    bool CheckModuleIntegrity(const std::string& moduleName);
    bool CheckAllModules();

    uint32_t CalculateCRC32(const uint8_t* data, uint64_t size);
    uint64_t CalculateFileHash(const std::string& filePath);

    bool SetMemoryProtection(uint8_t* address, uint64_t size, bool readOnly);

    bool IsMemoryModified(uint8_t* address, uint64_t size, uint32_t expectedCRC);
    bool MonitorMemoryRegion(uint8_t* address, uint64_t size, uint32_t expectedCRC);

private:
    CORE_NO_COPY_MOVE(CCodeIntegrity);

    bool EnumerateModules();
    bool GetModuleInfo(HMODULE hModule, SModuleInfo& outInfo);
    bool GetCodeSections(HMODULE hModule, std::vector<SCodeSection>& outSections);

    uint32_t CRC32(const uint8_t* data, uint64_t size);
    
    void OnIntegrityViolation(const std::string& reason);

    EFeatureState m_state;
    std::vector<SCodeSection> m_protectedSections;
    std::map<std::string, SModuleInfo> m_modules;
    uint64_t m_lastCheckTime;
    bool m_isMonitoring;
};

} // namespace MFS::CoreLock
