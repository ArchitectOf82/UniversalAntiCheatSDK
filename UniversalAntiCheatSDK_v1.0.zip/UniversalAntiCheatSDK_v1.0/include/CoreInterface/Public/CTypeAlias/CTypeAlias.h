#pragma once
#pragma execution_character_set("utf-8")

#include <cstdint>
#include <cstddef>

namespace MFS::CoreLock {

/**
 * @brief 数值类型别名定义，统一项目内数值类型使用规范
 * 
 * 项目中禁止直接使用原生 int/float/double 等类型，
 * 必须使用本文件定义的别名以确保类型一致性和可移植性。
 */

using u8  = std::uint8_t;
using u16 = std::uint16_t;
using u32 = std::uint32_t;
using u64 = std::uint64_t;

using i8  = std::int8_t;
using i16 = std::int16_t;
using i32 = std::int32_t;
using i64 = std::int64_t;

using s8  = std::int8_t;
using s16 = std::int16_t;
using s32 = std::int32_t;
using s64 = std::int64_t;

using f32 = float;
using f64 = double;

using ptrdiff = std::ptrdiff_t;
using size    = std::size_t;
using uptr    = std::uintptr_t;

using byte = u8;

} // namespace MFS::CoreLock

namespace MFS {
using MFS::CoreLock::u8;
using MFS::CoreLock::u16;
using MFS::CoreLock::u32;
using MFS::CoreLock::u64;
using MFS::CoreLock::i8;
using MFS::CoreLock::i16;
using MFS::CoreLock::i32;
using MFS::CoreLock::i64;
using MFS::CoreLock::s8;
using MFS::CoreLock::s16;
using MFS::CoreLock::s32;
using MFS::CoreLock::s64;
using MFS::CoreLock::f32;
using MFS::CoreLock::f64;
using MFS::CoreLock::ptrdiff;
using MFS::CoreLock::size;
using MFS::CoreLock::uptr;
using MFS::CoreLock::byte;
} // namespace MFS