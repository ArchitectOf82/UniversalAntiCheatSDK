﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/IFeature/EFeatureState.h"

#include <vector>
#include <string>

namespace MFS::CoreLock {

/**
 * @brief 顶层标准接口，所有业务模块的统一父接口
 * 
 * 所有功能模块必须实现此接口，确保模块管理器能够统一管理、初始化、更新和销毁。
 * 业务模块实体类必须同时继承 CSingleton<T> + IFeature。
 */
class IFeature
{
public:
    /**
     * @brief 初始化模块
     * 
     * 执行模块的初始化逻辑，包括资源加载、依赖检查、配置读取等。
     * 模块管理器会在依赖模块全部就绪后调用此方法。
     * 
     * @return true 初始化成功，模块进入 Ready 状态
     * @return false 初始化失败，模块进入 Error 状态
     */
    virtual bool Initialize() = 0;

    /**
     * @brief 每帧更新
     * 
     * 在引擎主循环中被调用，执行模块的每帧业务逻辑。
     * 只有 Ready 状态的模块才会收到 Update 调用。
     * 
     * @param deltaTime 帧间隔时间（秒）
     */
    virtual void Update(f32 deltaTime) = 0;

    /**
     * @brief 关闭模块
     * 
     * 执行模块的清理逻辑，释放所有已分配资源。
     * 模块管理器会按依赖逆序调用此方法。
     */
    virtual void Shutdown() = 0;

    /**
     * @brief 获取模块依赖列表
     * 
     * 返回当前模块依赖的其他模块名称列表，用于模块管理器进行拓扑排序。
     * 依赖的模块会在当前模块之前被初始化。
     * 
     * @param outDepList 输出参数，用于存储依赖模块名称列表
     */
    virtual void GetDependencyList(std::vector<std::string>& outDepList) const = 0;

    /**
     * @brief 获取模块当前状态
     * 
     * @return 模块生命周期状态
     */
    virtual EFeatureState GetState() const noexcept = 0;

    /**
     * @brief 虚析构函数
     */
    virtual ~IFeature() noexcept = default;
};

} // namespace MFS::CoreLock

namespace MFS {
using MFS::CoreLock::IFeature;
using MFS::CoreLock::EFeatureState;
} // namespace MFS