﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"

namespace MFS::CoreLock {

/**
 * @brief 模块生命周期状态枚举
 * 
 * 定义了所有功能模块的标准生命周期状态，用于模块管理器进行拓扑加载和状态监控。
 * 状态转换顺序：Uninitialized → Initializing → Ready → Updating → Shutdown → Destroyed
 * Error 状态可在任意阶段进入，表示模块异常。
 */
enum class EFeatureState : uint32_t
{
    Uninitialized = 0,
    Initializing,
    Ready,
    Updating,
    Error,
    Shutdown,
    Destroyed
};

/**
 * @brief 将模块状态转换为字符串
 * 
 * @param state 模块状态枚举值
 * @return 状态对应的字符串描述
 */
const char* FeatureStateToString(EFeatureState state) noexcept;

} // namespace MFS::CoreLock