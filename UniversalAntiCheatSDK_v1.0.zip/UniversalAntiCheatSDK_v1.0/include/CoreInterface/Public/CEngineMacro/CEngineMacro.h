﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"

namespace MFS::CoreLock {

/**
 * @brief 禁用拷贝构造和移动构造的宏
 * 
 * 使用方式：在类声明中直接添加一行 CORE_NO_COPY_MOVE(类名)
 * 适用于单例类、资源管理类等禁止拷贝的场景
 */
#define CORE_NO_COPY_MOVE(ClassName) \
    ClassName(const ClassName&) = delete; \
    ClassName(ClassName&&) = delete; \
    ClassName& operator=(const ClassName&) = delete; \
    ClassName& operator=(ClassName&&) = delete;

/**
 * @brief 断言宏，仅在非Release模式下生效
 * 
 * @param expr 断言表达式，为false时触发断言
 * @param msg  断言失败时的错误信息
 */
#ifndef CORE_ASSERT
#if defined(_DEBUG) || !defined(NDEBUG)
#define CORE_ASSERT(expr, msg) \
    do { \
        if (!(expr)) { \
            ::OutputDebugStringA("[CORE_ASSERT FAILED] " __FILE__ "(" STRINGIZE(__LINE__) "): " msg "\n"); \
            __debugbreak(); \
        } \
    } while (0)
#else
#define CORE_ASSERT(expr, msg) ((void)(expr))
#endif
#endif

/**
 * @brief 将数字转换为字符串的辅助宏
 */
#define STRINGIZE(x) #x

/**
 * @brief 内存对齐宏
 * 
 * @param align 对齐字节数，必须是2的幂
 */
#define CORE_ALIGN(align) __declspec(align(align))

/**
 * @brief 导出宏（Windows平台）
 */
#ifdef CORE_EXPORT
#define CORE_API __declspec(dllexport)
#else
#define CORE_API __declspec(dllimport)
#endif

/**
 * @brief 强制内联宏
 */
#define CORE_FORCE_INLINE __forceinline

/**
 * @brief 可能未使用的参数，用于消除编译器警告
 */
#define CORE_UNUSED(x) ((void)(x))

/**
 * @brief 数组大小计算宏
 */
#define CORE_ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))

/**
 * @brief 安全删除指针并置空
 */
#define CORE_SAFE_DELETE(ptr) \
    do { \
        if (ptr) { \
            delete ptr; \
            ptr = nullptr; \
        } \
    } while (0)

/**
 * @brief 安全删除数组指针并置空
 */
#define CORE_SAFE_DELETE_ARRAY(ptr) \
    do { \
        if (ptr) { \
            delete[] ptr; \
            ptr = nullptr; \
        } \
    } while (0)

} // namespace MFS::CoreLock