﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"

#include <mutex>
#include <memory>

namespace MFS::CoreLock {

/**
 * @brief 单例模板类
 * 
 * 提供线程安全的单例模式实现，所有业务模块实体类必须同时继承此类和 IFeature。
 * 使用方式：class MyModule : public CSingleton<MyModule>, public IFeature
 * 获取实例：&MyModule::GetInstance()
 * 
 * @tparam T 派生类类型，必须同时继承 CSingleton<T> 和 IFeature
 */
template<typename T>
class CSingleton
{
public:
    /**
     * @brief 获取单例实例
     * 
     * 线程安全的懒汉模式实现，首次调用时创建实例。
     * 使用方式：&T::GetInstance()
     * 
     * @return 单例实例的引用
     */
    static T& GetInstance()
    {
        static std::mutex s_mutex;
        std::lock_guard<std::mutex> lock(s_mutex);
        
        if (!s_instance)
        {
            s_instance = std::unique_ptr<T>(new T());
        }
        
        return *s_instance;
    }

protected:
    /**
     * @brief 默认构造函数
     * 
     * 受保护的构造函数，禁止外部直接实例化
     */
    CSingleton() = default;

    /**
     * @brief 虚析构函数
     * 
     * 受保护的析构函数，确保通过 unique_ptr 正确销毁
     */
    virtual ~CSingleton() noexcept = default;

private:
    /**
     * @brief 禁用拷贝构造和移动构造
     */
    CORE_NO_COPY_MOVE(CSingleton);

    /**
     * @brief 单例实例指针
     */
    static inline std::unique_ptr<T> s_instance = nullptr;
};

} // namespace MFS::CoreLock

namespace MFS {
using MFS::CoreLock::CSingleton;
} // namespace MFS