﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"
#include "CoreInterface/Public/CEngineMacro/CEngineMacro.h"
#include "CoreInterface/Public/ILog/ELogLevel.h"

#include <string>

namespace MFS::CoreLock {

/**
 * @brief 日志抽象接口
 * 
 * 定义日志系统的标准接口，支持多种日志级别和输出目标。
 * 所有日志实现必须继承此接口。
 */
class ILog
{
public:
    /**
     * @brief 虚析构函数
     */
    virtual ~ILog() noexcept = default;

    /**
     * @brief 输出 Trace 级别日志
     * 
     * 最详细的日志级别，用于追踪程序执行流程。
     * 
     * @param message 日志消息
     * @param file 源文件名称
     * @param line 行号
     */
    virtual void Trace(const std::string& message, const char* file = nullptr, uint32_t line = 0) = 0;

    /**
     * @brief 输出 Debug 级别日志
     * 
     * 调试信息，通常在开发阶段使用。
     * 
     * @param message 日志消息
     * @param file 源文件名称
     * @param line 行号
     */
    virtual void Debug(const std::string& message, const char* file = nullptr, uint32_t line = 0) = 0;

    /**
     * @brief 输出 Info 级别日志
     * 
     * 一般信息，记录程序运行状态。
     * 
     * @param message 日志消息
     * @param file 源文件名称
     * @param line 行号
     */
    virtual void Info(const std::string& message, const char* file = nullptr, uint32_t line = 0) = 0;

    /**
     * @brief 输出 Warning 级别日志
     * 
     * 警告信息，表示可能存在问题但不影响程序运行。
     * 
     * @param message 日志消息
     * @param file 源文件名称
     * @param line 行号
     */
    virtual void Warning(const std::string& message, const char* file = nullptr, uint32_t line = 0) = 0;

    /**
     * @brief 输出 Error 级别日志
     * 
     * 错误信息，表示发生了错误但程序可以继续运行。
     * 
     * @param message 日志消息
     * @param file 源文件名称
     * @param line 行号
     */
    virtual void Error(const std::string& message, const char* file = nullptr, uint32_t line = 0) = 0;

    /**
     * @brief 输出 Critical 级别日志
     * 
     * 严重错误，表示发生了致命错误，程序可能无法继续运行。
     * 
     * @param message 日志消息
     * @param file 源文件名称
     * @param line 行号
     */
    virtual void Critical(const std::string& message, const char* file = nullptr, uint32_t line = 0) = 0;

    /**
     * @brief 设置日志过滤级别
     * 
     * 低于此级别的日志将被过滤，不会输出。
     * 
     * @param level 过滤级别
     */
    virtual void SetFilterLevel(ELogLevel level) = 0;

    /**
     * @brief 获取当前日志过滤级别
     * 
     * @return 当前过滤级别
     */
    virtual ELogLevel GetFilterLevel() const = 0;

    /**
     * @brief 设置是否输出到控制台
     * 
     * @param enable true 启用控制台输出，false 禁用
     */
    virtual void SetConsoleOutput(bool enable) = 0;

    /**
     * @brief 设置是否输出到文件
     * 
     * @param enable true 启用文件输出，false 禁用
     */
    virtual void SetFileOutput(bool enable) = 0;

    /**
     * @brief 设置日志文件路径
     * 
     * @param path 文件路径
     */
    virtual void SetLogFilePath(const std::string& path) = 0;
};

} // namespace MFS::CoreLock