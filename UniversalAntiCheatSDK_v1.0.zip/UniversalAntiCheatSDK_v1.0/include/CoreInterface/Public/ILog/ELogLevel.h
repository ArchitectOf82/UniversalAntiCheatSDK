﻿#pragma once
#pragma execution_character_set("utf-8")

#include "CoreInterface/Public/CTypeAlias/CTypeAlias.h"

namespace MFS::CoreLock {

/**
 * @brief 日志级别枚举
 * 
 * 定义日志输出的严重程度级别，用于过滤和分类日志信息。
 * 级别越高，日志越重要。
 */
enum class ELogLevel : uint32_t
{
    Trace = 0,
    Debug,
    Info,
    Warning,
    Error,
    Critical
};

/**
 * @brief 将日志级别转换为字符串
 * 
 * @param level 日志级别枚举值
 * @return 级别的字符串描述
 */
const char* LogLevelToString(ELogLevel level) noexcept;

/**
 * @brief 判断日志级别是否应该输出
 * 
 * @param level 当前日志级别
 * @param filterLevel 过滤级别
 * @return true 应该输出，false 不应输出
 */
bool ShouldLog(ELogLevel level, ELogLevel filterLevel) noexcept;

} // namespace MFS::CoreLock