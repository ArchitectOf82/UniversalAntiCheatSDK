# UniversalAntiCheatSDK —— 游戏通用反作弊 SDK

从 `CoreLock SDK` 反作弊模块**独立抽取**的一套自包含、可跨游戏嵌入的反作弊库。
原项目源码零改动，本目录是完整独立副本，可单独构建、分发、接入任意游戏。

> 定位：**防御性反作弊**，用于你自己的游戏/服务端接入。检测目标应是你控制的程序（隔离靶机），
> 不要对正在运行的第三方商业游戏（如 PUBG）做进程扫描/内存读取——其内核反作弊会把你误判为作弊工具。

---

## 一、目录结构

```
G:\UniversalAntiCheatSDK\
├── include\CoreInterface\Public\         # 自包含薄框架依赖（类型别名/宏/单例/接口/日志接口）
├── Source\
│   ├── AntiCheat\{Public,Private}\        # 反作弊顶层：Hub 总控 / Kernel 内核保护 / Memory 内存 / Learn 自学习 / FileProtector
│   ├── CoreImpl\AntiCheat\{Public,Private}\# 底层实现：反调试/代码完整性/硬件指纹/时间锁/自毁/在线激活/许可证/混淆...
│   ├── CoreImpl\LogSystem\                # 日志依赖（CLogManager）
│   ├── CoreImpl\BaseTemplate\             # 日志辅助（ELogLevel）
│   └── Util\                              # 工具枚举（EUtilResult）
├── build\                                 # 构建产物：AntiCheat.lib、compile_run.bat（重建库脚本）
├── examples\demo\                         # 可运行 demo（语音公示演示 + AI 反作弊演示）
├── python\anti_cheat_llm_server.py        # 云端 LLM 分析服务（AI 接管反作弊的可选后端）
└── README.md
```

**已编译产物**：`build\AntiCheat.lib`（静态库，24 个模块单元，含 AI 分析模块）
**可运行 demo**：`examples\demo\demo_voice_warning.exe`、`examples\demo\demo_ai_anticheat.exe`（需先启动 python 分析服务）

---

## 二、构建方法

### Windows（本机已验证）
```bat
:: 1) 重建静态库（若改过源码）
G:\UniversalAntiCheatSDK\build\compile_run.bat   :: 编译全部源文件到 obj\
:: lib 已随附，如需重新打包在 obj 目录执行：lib /out:AntiCheat.lib *.obj

:: 2) 编译 demo
G:\UniversalAntiCheatSDK\examples\demo\build_demo.bat
```

### 跨平台（CMake，供其它机器 / Linux 服务端）
```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
```
> 说明：底层 `CAdvancedAntiDebug`（反调试）、`CHardwareFingerprint`（硬件指纹）等为 **Windows 客户端专属**。
> Linux 服务端侧重**数据上报 / 行为分析 / 在线验证 / 决策**，接入点在 `CAntiCheatHub` 的回调与自定义模块处，
> 平台相关文件用 `#ifdef _WIN32 / __linux__` 隔离。

---

## 三、运行 demo（隔离靶机 + 语音公示）

### 演示面板（推荐：一键启动所有 demo）

双击 `examples\demo\demo_panel.exe` 打开 **GUI 演示面板**：
- 窗口展示 SDK 能力说明 + 运行日志
- 三个按钮直接启动对应 demo：**① 语音点名演示 / ② AI 反作弊演示 / ③ 激活试用演示**

```bat
G:\UniversalAntiCheatSDK\examples\demo\demo_panel.exe
```

### 单独运行 demo

```bat
G:\UniversalAntiCheatSDK\examples\demo\demo_voice_warning.exe
```

demo 演示流程：
1. 初始化反作弊 Hub（日志 + 内核保护 + 文件保护）
2. 注册一个「模拟作弊检测器」`FakeCheatDetector`（隔离靶机，不扫描任何外部进程）
3. 数帧后判定目标玩家 `Player_0786` 开科技
4. 触发**语音公示**：
   - **全局广播**：向所有玩家播报「当前有人开科技」并点名作弊者 ID
   - **私聊通道**：单独一条语音只发给作弊者本人（「系统绑定中，绑定失败，开科技了菜鸡」）
5. 语音用 Windows SAPI TTS 朗读（系统未装中文语音则退回控制台文本）

### AI 反作弊 demo（云端 LLM 判定）

**前置**：先启动云端分析服务（需 Python 3.8+）：
```bat
python python\anti_cheat_llm_server.py        :: 默认监听 127.0.0.1:9001
```
可选配环境变量（配了才走真 LLM；不配则本地规则兜底）：
```
AI_OLLAMA_HOST=http://127.0.0.1:11434     :: 本地 Ollama（优先）
AI_API_URL=https://api.deepseek.com/v1/chat/completions
AI_API_KEY=你的key
AI_MODEL=deepseek-chat
```

然后编译并运行 AI demo：
```bat
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
build\examples\demo\demo_ai_anticheat.exe
```

demo 演示流程：初始化 Hub → 注册 `CAIAntiCheatModule`（开启内置模拟玩家，自动注入作弊者 `Player_0007`）→ 行为特征聚合后上报 LLM 服务 → AI 判定作弊 → 回调触发警告。

---

## 四、接入你自己的游戏

```cpp
#include "Source/AntiCheat/Public/CAntiCheatHub.h"
#include "Source/CoreImpl/AntiCheat/Public/IAntiCheatModule.h"
using namespace MFS::CoreLock;

// 1) 初始化
CLogManager::GetInstance().Initialize();
CAntiCheatHub& hub = CAntiCheatHub::GetInstance();
hub.Initialize();
hub.StartProtection();

// 2) 注册自定义检测器（游戏通用能力扩展点）
class CWallhackDetector : public IAntiCheatModule {
    const char* GetName() const override { return "WallhackDetector"; }
    bool Check(SAntiCheatResult& out) override {
        out.passed = /* 你的检测逻辑 */;
        out.checkName = "WallhackDetector";
        out.severity = 0.9f;
        return out.passed;
    }
};
hub.RegisterModule("Wallhack", std::make_unique<CWallhackDetector>());

// 3) 语音公示：检测到作弊 → 全局点名 + 私聊
hub.RegisterCallback([](const SAntiCheatResult& r){
    if (r.passed) return;
    // 全局广播（面向所有客户端）
    BroadcastGlobal("当前有人开科技！作弊者ID " + r.reason + "，已定位。");
    // 私聊通道（仅发给作弊者本人）
    SendPrivateTo(r.reason, "系统绑定中，绑定失败，开科技了菜鸡。");
});

// 4) 每帧驱动
// ... 游戏主循环中调用 hub.Update(deltaTime);

// 5) 退出
hub.StopProtection();
hub.Shutdown();
```

---

## 四·五、语音内容自定义（文案完全由你定）

**核心一句话**：反作弊检测是 SDK 做的；**语音播什么、怎么说，全是开发者自己的字符串**，SDK 不限制。语音播报发生在 Hub 回调里（检测到作弊时触发），你在回调里自己写文案即可。

**在哪里改**：`hub.RegisterCallback(...)` 的回调体内——`r.reason` 是作弊者标识，`r.checkName` 是违规类型，你想怎么念就怎么拼。

**完整可复制示例（含 SAPI 语音封装，直接可用）：**
```cpp
#include "Source/AntiCheat/Public/CAntiCheatHub.h"
#include <string>
#include <wchar.h>
#ifdef _WIN32
#include <windows.h>
#include <sapi.h>
#endif

// ---- 语音封装：把 UTF-8 字符串用 Windows SAPI 朗读（系统没装中文语音则静默，不影响逻辑）----
static std::wstring ToWide(const std::string& s) {
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    std::wstring w(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}
static void SpeakText(const std::wchar_t* text) {
    if (!text || !*text) return;
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    ISpVoice* p = nullptr;
    if (SUCCEEDED(CoCreateInstance(CLSID_SpVoice, nullptr, CLSCTX_ALL,
                                   IID_ISpVoice, (void**)&p)))
        p->Speak(text, SPF_IS_XML, nullptr);   // 同步播放，播完释放，防闪退
    if (p) p->Release();
    CoUninitialize();
}

// ---- 语音播报：文案完全自己定 ----
hub.RegisterCallback([](const SAntiCheatResult& r) {
    if (r.passed) return;

    // 1) 全局点名（广播给所有玩家）
    std::string global = "当前有人开科技！作弊者ID " + r.reason + "，已定位。";
    printf("%s\n", global.c_str());
    SpeakText(ToWide(global).c_str());

    // 2) 私聊威慑（单独发给作弊者本人）
    std::string privateMsg = "系统绑定中，绑定失败，开科技了菜鸡。";
    SpeakText(ToWide(privateMsg).c_str());
});
```

**进阶：按违规类型 / 次数切换不同话术（推荐做话术表）：**
```cpp
hub.RegisterCallback([](const SAntiCheatResult& r) {
    if (r.passed) return;

    std::string global;
    if (r.checkName.find("Speed") != std::string::npos)
        global = "玩家 " + r.reason + " 移动异常，疑似加速，已记录。";
    else if (r.checkName.find("Aim") != std::string::npos)
        global = "玩家 " + r.reason + " 锁头嫌疑，已定位。";
    else
        global = "玩家 " + r.reason + " 违规，已记录。";

    std::string privateMsg = r.reason + "，你的小动作被系统看见了，收敛点。";
    SpeakText(ToWide(global).c_str());
    SpeakText(ToWide(privateMsg).c_str());
});
```

**关键提示**：
- demo 里的 `BroadcastGlobal(...)` / `SendPrivateTo(...)` 是**示意函数**（本地演示用 SAPI 朗读）；真实接入时，这两处对接**你自己的语音 / 聊天消息通道**（服务端广播、客户端播报），文案写法完全一样。
- 语音用 Windows SAPI TTS（`demo_voice_warning.cpp` 的 `SpeakText` 即此封装）；系统未装中文语音则退回控制台文本，不影响检测逻辑。
- 想改音色/语速，用 `p->SetVolume(100)`、`p->SetRate(0)` 等 SAPI 接口。

**标准生命周期**：`Initialize()` → `StartProtection()` → 每帧 `Update(dt)` → `StopProtection()` → `Shutdown()`。

---

## 五、内置检测能力（游戏通用）

| 检测器 | 能力 |
|--------|------|
| `CAdvancedAntiDebug` | 反调试：调试器附加、进程钩子检测 |
| `CAntiCheatMemory` | 内存校验、篡改检测、变速识别 |
| `CCodeIntegrity` | 代码完整性（VirtualProtect/Hook 防护） |
| `CHardwareFingerprint` | 硬件指纹（CPU/GPU/主板/磁盘/BIOS/MAC） |
| `CTimeLock` | 时间锁 / 变速时间戳校验 |
| `CStealthSelfDestruct` | 自毁 / 受威胁保护响应 |
| `CDynamicMazeGuard` | 动态混淆 / 迷宫守卫 |
| `CGameAntiCheatLearn` | 行为自学习 / 异常模式识别 |
| `CAIAntiCheatModule` | **AI 反作弊分析**：行为特征采集 → 上报云端 LLM 判定（作弊/疑似/正常），服务不可达自动降级本地规则 |
| `CFileProtector` | 文件完整性保护 |
| `CSDKProtectionManager` | SDK 运行期保护 |
| `COnlineActivation` / `CSDKLicenseManager` | 在线激活 / 许可证绑定 |

`IAntiCheatModule` 插件机制：任何游戏可 `RegisterModule` 挂自己的检测器（透视、自瞄、经济异常等）——**这是"游戏通吃"的扩展入口**。

---

## 五·五、AI 反作弊分析模块（AI 接管）

让规则检测之外的**行为分析**交给 AI：把玩家行为特征（速度/加速度/瞄准精度/反应时间/命中率/操作频率等）上报给大模型，由 AI 判断是真人还是外挂/脚本/超人类反应，能识别规则难覆盖的隐蔽作弊并降低误报。

**工作原理（双层，断网自动降级）：**
```
游戏端 → ReportBehavior(行为样本) → 聚合 → HTTP 上报 → Python 分析服务 → LLM 判定
                                                          （Ollama 优先 / OpenAI 兼容 API 兜底）
                    └─ 云端不可达 → 本地规则兜底（速度>25 / 反应<90ms / 瞄准>98.5% / 操作>40次/秒）
```

**按玩家独立判定（重要）：** 模块对**每个玩家独立**采集、聚合、上报、判定——`ReportBehavior` 按 `playerId` 分桶，各玩家互不影响，作弊者的异常特征**不会被其他正常玩家稀释**。真实接入时，对每个在线玩家各自喂行为数据即可。

**真实游戏接入（关掉 demo，喂真实行为数据）：**
```cpp
#include "Source/AntiCheat/Public/CAntiCheatHub.h"
#include "Source/AntiCheat/Public/CAIAntiCheatModule.h"
using namespace MFS::CoreLock;

// 1) 创建并配置 AI 模块
auto ai = std::make_unique<CAIAntiCheatModule>();
ai->SetLLMEndpoint("http://127.0.0.1:9001/analyze");  // 云端分析服务地址
ai->SetEnableDemo(false);                              // 关掉内置模拟，改接真实数据
ai->SetReportIntervalSec(2.0f);                        // 聚合上报间隔
// （可选）调整本地兜底阈值
ai->SetSpeedThreshold(25.f);
ai->SetReactionThresholdMs(90.f);
ai->SetAimThreshold(0.985f);
hub.RegisterModule("AIAnalysis", std::move(ai));       // 注册进 Hub

// 2) 每个玩家每帧/定时喂行为数据
SBehaviorSample s;
s.playerId = "Player_1234";
s.speed = 3.2f;              // m/s
s.reactionTimeMs = 220.f;    // ms
s.aimPrecision = 0.4f;       // 0~1
s.hitRate = 0.2f;
s.opFrequency = 4.f;
ai->ReportBehavior(s);

// 3) AI 判定作弊 → 走现有回调（可选接语音警告）
hub.RegisterCallback([](const SAntiCheatResult& r){
    if (r.passed) return;
    // r.reason 形如 "AI(llm)判定作弊：移动速度异常(40m/s)"
    BroadcastGlobal("当前有人开科技！" + r.reason);
});
```

> **回调触发频率（checkIntervalMs）**：AI 判定作弊后走 Hub 回调，实际由 Hub 的 `checkIntervalMs` 决定——检查间隔到才执行一次自定义模块检查。demo 里设为 500ms 便于快速演示；真实接入按你的检测节奏调，例：
> ```cpp
> SAntiCheatConfig cfg = hub.GetConfig();
> cfg.checkIntervalMs = 1000;   // 每 1 秒检查一次自定义模块并触发回调
> hub.SetConfig(cfg);
> ```

**接口一览（CAIAntiCheatModule）：**

| 接口 | 说明 |
|------|------|
| `SetLLMEndpoint(url)` | 云端分析服务地址（默认 http://127.0.0.1:9001/analyze） |
| `SetEnableDemo(bool)` | 内置模拟玩家演示开关（真实接入设 false） |
| `SetReportIntervalSec(sec)` | 聚合上报间隔（默认 2s，最小 0.2s） |
| `ReportBehavior(SBehaviorSample)` | 喂入**单个玩家**行为样本（按 playerId 分桶，核心入口） |
| `hub.SetConfig(checkIntervalMs)` | 自定义模块检查/回调触发间隔（demo 用 500ms，真实按需） |
| `SetSpeedThreshold/ReactionThresholdMs/AimThreshold` | 本地兜底阈值（降级时用） |
| `IsCloudReachable()` | 云端是否可达（可展示在 HUD） |
| `GetLastVerdict()` | 最近一次判定（cheat/suspect/normal + 置信度 + 理由） |

> 说明：LLM 判定是**辅助参考**，最终是否封禁由游戏方决定；AI 只做检测与上报，不含任何对第三方系统的攻击/入侵。

---

## 六、安全测试提醒（重要）

- ✅ 用**隔离靶机**（自己写的假游戏进程）验证检测器，最安全。
- ⚠️ 不要对正在运行的第三方商业游戏做进程扫描 / 内存读取 / 模块枚举——会被其反作弊误判封号。
- ❌ 本 SDK 不提供任何对抗第三方反作弊（BattlEye 等）的手段。

---

## 七、后续可扩展

- **Linux 服务端**：行为分析（`CGameAntiCheatLearn`）跨平台化 + 数据上报/决策服务，可用 CMake 交叉编译。
- **SQL 落库**：封禁记录、作弊证据、硬件指纹黑名单存储。
- **公示层升级**：全局播报 / 私聊通道对接真实语音 TTS 服务（如云端 TTS）。
